# BABLOSHARE

BABLOSHARE is a real-data social video platform for discovering creators, publishing short and long-form video, and building connections.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/babloshare/src/App.tsx` — responsive public, auth, feed, search, publishing, and profile UI.
- `artifacts/api-server/src/routes/` — Express API routes for auth, videos, comments, follows, profiles, and search.
- `lib/api-spec/openapi.yaml` — source of truth for API contracts and generated hooks.
- `lib/db/src/schema/` — PostgreSQL/Drizzle models for users, profiles, videos, posts, follows, likes, and comments.
- `artifacts/babloshare/src/index.css` — BABLOSHARE theme and responsive visual system.

## Architecture decisions

- Auth uses bcryptjs password hashing and short-lived bearer JWTs signed with `SESSION_SECRET`; the web client stores only the returned token and attaches it through the shared fetch client.
- Counts and interaction state are read from PostgreSQL on each relevant API response; no seed metrics, fake views, or simulated social proof are used.
- Video media is published by URL in Phase 1; the schema keeps playback and thumbnail URLs ready for object-storage integration without storing file bytes in PostgreSQL.
- API shapes are defined in OpenAPI first and consumed through generated React Query hooks.

## Product

- Public brand landing page with BABLOSHARE identity and Connect. Create. Share. positioning.
- Email/password registration and login with protected publishing and interaction routes.
- Short-form discovery feed, long-form browse, universal search, creator profiles, and mobile navigation.
- Persisted video likes, comments, follows, and video publishing backed by PostgreSQL.

## User preferences

- No fake metrics, fake views, fake followers, or simulated financial data.

## Gotchas

- `SESSION_SECRET` is required by the API workflow.
- Run OpenAPI codegen after changing `lib/api-spec/openapi.yaml`.
- Web builds need workflow-provided `PORT` and `BASE_PATH`; run the managed web workflow or provide both variables for a manual build.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
