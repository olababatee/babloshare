---
name: Stripe sync migrations
description: Runtime migration asset resolution when using stripe-replit-sync in a bundled API server.
---

When an API server is bundled with esbuild, keep `stripe-replit-sync` external so its packaged migration SQL remains available at runtime.

**Why:** `runMigrations()` locates SQL relative to the package directory. Bundling relocates that path and can silently skip migrations, leaving required Stripe tables missing during webhook setup.

**How to apply:** Before calling `runMigrations()` from a bundled server, verify the package resolves from its installed location and that migrations execute; do not create Stripe-owned tables manually.
