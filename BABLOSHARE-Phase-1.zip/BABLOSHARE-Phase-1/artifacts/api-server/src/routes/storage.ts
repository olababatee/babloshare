import { and, eq, isNull, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  conversationMembersTable,
  db,
  followsTable,
  messagesTable,
  pagesTable,
  postsTable,
  profilesTable,
  storiesTable,
  videosTable,
} from "@workspace/db";
import { RequestStorageUploadBody, CompleteStorageUploadBody } from "@workspace/api-zod";
import { optionalAuth, requireAuth } from "../lib/auth";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const storage = new ObjectStorageService();
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const imageMimeTypes = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const videoMimeTypes = new Set(["video/mp4", "video/webm", "video/quicktime"]);
const imageLimit = 15 * 1024 * 1024;
const videoLimit = 120 * 1024 * 1024;

function mediaKind(contentType: string): "image" | "video" | null {
  if (imageMimeTypes.has(contentType.toLowerCase())) return "image";
  if (videoMimeTypes.has(contentType.toLowerCase())) return "video";
  return null;
}

function canonicalMediaUrl(path: string): string {
  return `/api/storage/object-url?path=${encodeURIComponent(path)}`;
}

function matchesFileSignature(bytes: Buffer, contentType: string): boolean {
  const mime = contentType.toLowerCase();
  if (mime === "image/jpeg") return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  if (mime === "image/png") return bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  if (mime === "image/gif") return bytes.subarray(0, 6).toString("ascii").startsWith("GIF8");
  if (mime === "image/webp") return bytes.subarray(0, 4).toString("ascii") === "RIFF" && bytes.subarray(8, 12).toString("ascii") === "WEBP";
  if (mime === "video/mp4") return bytes.subarray(4, 8).toString("ascii") === "ftyp";
  if (mime === "video/quicktime") return bytes.subarray(4, 8).toString("ascii") === "ftyp" && bytes.subarray(8, 12).toString("ascii").startsWith("qt");
  if (mime === "video/webm") return bytes.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]));
  return false;
}

async function canViewLinkedMedia(mediaUrl: string, viewerId?: string): Promise<boolean> {
  const [profileMedia] = await db.select({ id: profilesTable.id }).from(profilesTable)
    .where(or(eq(profilesTable.avatarUrl, mediaUrl), eq(profilesTable.coverUrl, mediaUrl))).limit(1);
  if (profileMedia) return true;

  const [post] = await db.select({ id: postsTable.id }).from(postsTable).where(eq(postsTable.mediaUrl, mediaUrl)).limit(1);
  if (post) return true;
  const [video] = await db.select({ id: videosTable.id }).from(videosTable)
    .where(or(eq(videosTable.playbackUrl, mediaUrl), eq(videosTable.thumbnailUrl, mediaUrl))).limit(1);
  if (video) return true;
  const [page] = await db.select({ id: pagesTable.id }).from(pagesTable)
    .where(or(eq(pagesTable.avatarUrl, mediaUrl), eq(pagesTable.coverUrl, mediaUrl))).limit(1);
  if (page) return true;

  const [story] = await db.select().from(storiesTable).where(eq(storiesTable.mediaUrl, mediaUrl)).limit(1);
  if (story) {
    if (story.visibility === "public") return true;
    if (viewerId) {
      const [viewerProfile] = await db.select({ id: profilesTable.id }).from(profilesTable).where(eq(profilesTable.userId, viewerId));
      const [authorProfile] = await db.select({ id: profilesTable.id }).from(profilesTable).where(eq(profilesTable.userId, story.authorId));
      if (viewerProfile && authorProfile) {
        const [follow] = await db.select({ followerId: followsTable.followerId }).from(followsTable)
          .where(and(eq(followsTable.followerId, viewerProfile.id), eq(followsTable.followingId, authorProfile.id)));
        if (follow) return true;
      }
    }
    return false;
  }

  const [message] = await db.select({ conversationId: messagesTable.conversationId }).from(messagesTable)
    .where(eq(messagesTable.mediaUrl, mediaUrl)).limit(1);
  if (message && viewerId) {
    const [member] = await db.select({ userId: conversationMembersTable.userId }).from(conversationMembersTable)
      .where(and(
        eq(conversationMembersTable.conversationId, message.conversationId),
        eq(conversationMembersTable.userId, viewerId),
        isNull(conversationMembersTable.blockedAt),
      ));
    return Boolean(member);
  }
  return false;
}

router.post("/storage/uploads/request-url", requireAuth, async (req, res): Promise<void> => {
  const parsed = RequestStorageUploadBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { size, contentType } = parsed.data;
  const kind = mediaKind(contentType);
  const maxSize = kind === "image" ? imageLimit : kind === "video" ? videoLimit : 0;
  if (!kind || size > maxSize) {
    res.status(400).json({ error: "Choose a supported image or video within the upload size limit." });
    return;
  }
  try {
    const result = await storage.getObjectEntityUploadURL(req.userId!);
    res.json(result);
  } catch (error) {
    req.log.error({ err: error }, "media_upload_url_failed");
    res.status(503).json({ error: "Media uploads are temporarily unavailable." });
  }
});

router.post("/storage/uploads/complete", requireAuth, async (req, res): Promise<void> => {
  const parsed = CompleteStorageUploadBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const match = /^\/objects\/uploads\/([0-9a-f-]{36})\/([0-9a-f-]{36})$/i.exec(parsed.data.objectPath);
  if (!match || !uuidPattern.test(match[1]) || !uuidPattern.test(match[2])) {
    res.status(400).json({ error: "Invalid uploaded media path." });
    return;
  }
  if (match[1].toLowerCase() !== req.userId!.toLowerCase()) {
    res.status(403).json({ error: "That upload does not belong to your account." });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(parsed.data.objectPath);
    const [metadata] = await file.getMetadata();
    const contentType = String(metadata.contentType || "").toLowerCase();
    const size = Number(metadata.size || 0);
    const kind = mediaKind(contentType);
    const maxSize = kind === "image" ? imageLimit : kind === "video" ? videoLimit : 0;
    const [signature] = await file.download({ start: 0, end: 31 });
    if (!kind || size < 1 || size > maxSize || !matchesFileSignature(signature, contentType)) {
      await file.delete({ ignoreNotFound: true });
      res.status(400).json({ error: "The uploaded file is not a supported image or video, or it exceeds the size limit." });
      return;
    }
    const customMetadata = (metadata.metadata ?? {}) as Record<string, string>;
    await file.setMetadata({
      metadata: {
        ...customMetadata,
        babloshareOwner: req.userId!,
        babloshareMediaType: kind,
        babloshareValidated: "true",
      },
    });
    const path = parsed.data.objectPath.slice("/objects/".length);
    res.json({ mediaUrl: canonicalMediaUrl(path), mediaType: kind, contentType, size });
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "The uploaded file was not found." });
      return;
    }
    req.log.error({ err: error }, "media_upload_complete_failed");
    res.status(500).json({ error: "Could not validate the uploaded file." });
  }
});

router.get("/storage/object-url", optionalAuth, async (req, res): Promise<void> => {
  const path = typeof req.query.path === "string" ? req.query.path : "";
  const match = /^uploads\/([0-9a-f-]{36})\/([0-9a-f-]{36})$/i.exec(path);
  if (!match || !uuidPattern.test(match[1]) || !uuidPattern.test(match[2])) {
    res.status(400).json({ error: "Invalid media path." });
    return;
  }
  const mediaUrl = canonicalMediaUrl(path);
  try {
    const objectPath = `/objects/${path}`;
    const file = await storage.getObjectEntityFile(objectPath);
    const [metadata] = await file.getMetadata();
    const customMetadata = (metadata.metadata ?? {}) as Record<string, string>;
    if (customMetadata.babloshareValidated !== "true" || customMetadata.babloshareOwner?.toLowerCase() !== match[1].toLowerCase()) {
      res.status(404).json({ error: "Media not found." });
      return;
    }
    const ownerCanView = req.userId?.toLowerCase() === match[1].toLowerCase();
    if (!ownerCanView && !(await canViewLinkedMedia(mediaUrl, req.userId))) {
      res.status(403).json({ error: "You do not have access to this media." });
      return;
    }
    const url = await storage.getObjectEntityDownloadURL(objectPath);
    res.setHeader("Cache-Control", "private, max-age=300");
    res.json({ url });
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Media not found." });
      return;
    }
    req.log.error({ err: error }, "media_read_url_failed");
    res.status(500).json({ error: "Could not prepare media playback." });
  }
});

export default router;
