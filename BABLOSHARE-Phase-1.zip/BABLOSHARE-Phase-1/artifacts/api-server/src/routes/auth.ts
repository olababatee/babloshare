import bcrypt from "bcryptjs";
import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, profilesTable, usersTable } from "@workspace/db";
import { GetCurrentUserResponse, LoginBody, RegisterBody } from "@workspace/api-zod";
import { optionalAuth, requireAuth, signUserToken } from "../lib/auth";
import { profileDto } from "../lib/present";

const router: IRouter = Router();

async function currentUserDto(user: typeof usersTable.$inferSelect) {
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, user.id));
  if (!profile) throw new Error("Profile not found");
  return { id: user.id, email: user.email, role: user.role, profile: await profileDto(profile, user.id) };
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const email = parsed.data.email.toLowerCase();
  const username = parsed.data.username.trim().toLowerCase();
  const existing = await db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.email, email));
  const existingUsername = await db.select({ id: profilesTable.id }).from(profilesTable).where(eq(profilesTable.username, username));
  if (existing.length || existingUsername.length) {
    res.status(409).json({ error: "Email or username is already in use" });
    return;
  }
  const passwordHash = await bcrypt.hash(parsed.data.password, 12);
  const [user] = await db.insert(usersTable).values({ email, passwordHash }).returning();
  const [profile] = await db.insert(profilesTable).values({
    userId: user.id,
    username,
    displayName: parsed.data.displayName,
    isCreator: true,
  }).returning();
  const payload = { id: user.id, email: user.email, role: user.role, profile: await profileDto(profile, user.id) };
  res.status(201).json({ token: signUserToken(user.id), user: payload });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, parsed.data.email.toLowerCase()));
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }
  if (user.accountStatus !== "active") {
    res.status(401).json({ error: "Invalid email or password" });
    return;
  }
  res.json({ token: signUserToken(user.id), user: await currentUserDto(user) });
});

router.get("/auth/me", optionalAuth, requireAuth, async (req, res): Promise<void> => {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.userId!));
  if (!user) {
    res.status(401).json({ error: "Session user not found" });
    return;
  }
  res.json(GetCurrentUserResponse.parse(await currentUserDto(user)));
});

export default router;