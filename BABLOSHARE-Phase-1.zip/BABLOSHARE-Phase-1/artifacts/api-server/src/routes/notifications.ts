import { and, count, desc, eq, isNull } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, notificationsTable, profilesTable, usersTable } from "@workspace/db";
import { requireAuth } from "../lib/auth";
import { creatorDto } from "../lib/present";

const router: IRouter = Router();

router.get("/notifications", requireAuth, async (req, res): Promise<void> => {
  const [unread] = await db.select({ count: count() }).from(notificationsTable)
    .where(and(eq(notificationsTable.recipientId, req.userId!), isNull(notificationsTable.readAt)));
  const rows = await db.select({
    notification: notificationsTable,
    profile: profilesTable,
  }).from(notificationsTable)
    .innerJoin(usersTable, eq(usersTable.id, notificationsTable.actorId))
    .innerJoin(profilesTable, eq(profilesTable.userId, usersTable.id))
    .where(eq(notificationsTable.recipientId, req.userId!))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(50);
  res.json({
    unreadCount: unread?.count ?? 0,
    items: await Promise.all(rows.map(async ({ notification, profile }) => ({
      id: notification.id,
      type: notification.type,
      entityType: notification.entityType,
      entityId: notification.entityId,
      readAt: notification.readAt,
      createdAt: notification.createdAt,
      actor: await creatorDto(profile),
    }))),
  });
});

router.post("/notifications/read", requireAuth, async (req, res): Promise<void> => {
  const updated = await db.update(notificationsTable)
    .set({ readAt: new Date() })
    .where(and(eq(notificationsTable.recipientId, req.userId!), isNull(notificationsTable.readAt)))
    .returning({ id: notificationsTable.id });
  res.json({ updatedCount: updated.length });
});

export default router;
