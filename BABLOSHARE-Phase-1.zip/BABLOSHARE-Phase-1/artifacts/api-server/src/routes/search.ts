import { desc, ilike, or, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { SearchQueryParams } from "@workspace/api-zod";
import { db, profilesTable, videosTable } from "@workspace/db";
import { optionalAuth } from "../lib/auth";
import { profileDto, videoDto } from "../lib/present";

const router: IRouter = Router();

router.get("/search", optionalAuth, async (req, res): Promise<void> => {
  const parsed = SearchQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const query = `%${parsed.data.q}%`;
  const [profiles, videos] = await Promise.all([
    db.select().from(profilesTable).where(or(ilike(profilesTable.username, query), ilike(profilesTable.displayName, query))).limit(parsed.data.limit ?? 10),
    db.select().from(videosTable).where(or(ilike(videosTable.title, query), ilike(videosTable.description, query))).orderBy(desc(videosTable.createdAt)).limit(parsed.data.limit ?? 10),
  ]);
  res.json({
    profiles: await Promise.all(profiles.map((profile) => profileDto(profile, req.userId))),
    videos: await Promise.all(videos.map((video) => videoDto(video, req.userId))),
  });
});

export default router;