import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import videosRouter from "./videos";
import profilesRouter from "./profiles";
import searchRouter from "./search";
import communityRouter from "./community";
import economyRouter from "./economy";
import postsRouter from "./posts";
import storageRouter from "./storage";
import notificationsRouter from "./notifications";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(videosRouter);
router.use(profilesRouter);
router.use(searchRouter);
router.use(communityRouter);
router.use(economyRouter);
router.use(postsRouter);
router.use(storageRouter);
router.use(notificationsRouter);
router.use(adminRouter);

export default router;
