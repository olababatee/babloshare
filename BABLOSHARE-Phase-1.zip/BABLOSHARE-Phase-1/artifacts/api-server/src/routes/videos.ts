import { and, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateVideoBody,
  CreateVideoCommentBody,
  CreateVideoCommentParams,
  GetCurrentUserResponse,
  ListVideoCommentsParams,
  ListVideosQueryParams,
  ToggleVideoLikeParams,
} from "@workspace/api-zod";
import { db, profilesTable, usersTable, videoCommentsTable, videoLikesTable, videosTable } from "@workspace/db";
import { optionalAuth, requireAuth } from "../lib/auth";
import { creatorDto, videoDto } from "../lib/present";
import { recordNotification } from "../lib/notifications";
import { MediaValidationError, validateStoredMedia } from "../lib/mediaValidation";

const router: IRouter = Router();

router.get("/videos", optionalAuth, async (req, res): Promise<void> => {
  const parsed = ListVideosQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const videos = await db.select().from(videosTable)
    .where(parsed.data.videoType ? eq(videosTable.videoType, parsed.data.videoType) : undefined)
    .orderBy(desc(videosTable.createdAt))
    .limit(parsed.data.limit ?? 20);
  res.json(await Promise.all(videos.map((video) => videoDto(video, req.userId))));
});

router.post("/videos", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateVideoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    await validateStoredMedia(parsed.data.playbackUrl, req.userId!, "video");
    if (parsed.data.thumbnailUrl) await validateStoredMedia(parsed.data.thumbnailUrl, req.userId!, "image");
  } catch (error) {
    res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
    return;
  }
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  const [video] = await db.insert(videosTable).values({
    ...parsed.data,
    creatorId: profile.id,
    thumbnailUrl: parsed.data.thumbnailUrl ?? null,
  }).returning();
  res.status(201).json(await videoDto(video, req.userId));
});

router.post("/videos/:id/like", requireAuth, async (req, res): Promise<void> => {
  const parsed = ToggleVideoLikeParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [video] = await db.select({ id: videosTable.id, creatorId: videosTable.creatorId }).from(videosTable).where(eq(videosTable.id, parsed.data.id));
  if (!video) {
    res.status(404).json({ error: "Video not found" });
    return;
  }
  const [existing] = await db.select().from(videoLikesTable).where(and(eq(videoLikesTable.userId, req.userId!), eq(videoLikesTable.videoId, parsed.data.id)));
  if (existing) {
    await db.delete(videoLikesTable).where(and(eq(videoLikesTable.userId, req.userId!), eq(videoLikesTable.videoId, parsed.data.id)));
  } else {
    const inserted = await db.insert(videoLikesTable).values({ userId: req.userId!, videoId: parsed.data.id }).onConflictDoNothing().returning();
    if (inserted.length) {
      const [owner] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, video.creatorId));
      if (owner) try {
        await recordNotification({ recipientId: owner.userId, actorId: req.userId!, type: "video_like", entityType: "video", entityId: video.id });
      } catch (error) { req.log.error({ err: error }, "notification_write_failed"); }
    }
  }
  const likes = await db.select().from(videoLikesTable).where(eq(videoLikesTable.videoId, parsed.data.id));
  res.json({ active: !existing, count: likes.length });
});

router.get("/videos/:id/comments", async (req, res): Promise<void> => {
  const parsed = ListVideoCommentsParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const comments = await db.select({
    id: videoCommentsTable.id,
    videoId: videoCommentsTable.videoId,
    content: videoCommentsTable.content,
    createdAt: videoCommentsTable.createdAt,
    author: profilesTable,
  }).from(videoCommentsTable)
    .innerJoin(usersTable, eq(usersTable.id, videoCommentsTable.userId))
    .innerJoin(profilesTable, eq(profilesTable.userId, usersTable.id))
    .where(eq(videoCommentsTable.videoId, parsed.data.id))
    .orderBy(desc(videoCommentsTable.createdAt));
  res.json(await Promise.all(comments.map(async (comment) => ({
    id: comment.id,
    videoId: comment.videoId,
    content: comment.content,
    createdAt: comment.createdAt,
    author: await creatorDto(comment.author),
  }))));
});

router.post("/videos/:id/comments", requireAuth, async (req, res): Promise<void> => {
  const params = CreateVideoCommentParams.safeParse(req.params);
  const body = CreateVideoCommentBody.safeParse(req.body);
  if (!params.success || !body.success) {
    const error = !params.success ? params.error.message : body.success ? "Invalid comment" : body.error.message;
    res.status(400).json({ error });
    return;
  }
  const [video] = await db.select({ id: videosTable.id, creatorId: videosTable.creatorId }).from(videosTable).where(eq(videosTable.id, params.data.id));
  if (!video) {
    res.status(404).json({ error: "Video not found" });
    return;
  }
  const [comment] = await db.insert(videoCommentsTable).values({
    videoId: params.data.id,
    userId: req.userId!,
    content: body.data.content,
  }).returning();
  const [owner] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, video.creatorId));
  if (owner) try {
    await recordNotification({ recipientId: owner.userId, actorId: req.userId!, type: "video_comment", entityType: "video", entityId: video.id });
  } catch (error) { req.log.error({ err: error }, "notification_write_failed"); }
  const [author] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  res.status(201).json({
    id: comment.id,
    videoId: comment.videoId,
    content: comment.content,
    createdAt: comment.createdAt,
    author: await creatorDto(author),
  });
});

export default router;