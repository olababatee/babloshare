import { and, count, desc, eq, inArray, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateCreatorOfferBody,
  CreateSubscriptionCheckoutBody,
  CreateTipCheckoutBody,
  GetCreatorOfferParams,
  ConfirmEconomyCheckoutParams,
  ListCreatorTransactionsResponse,
  RecordVideoViewBody,
  RecordVideoViewParams,
} from "@workspace/api-zod";
import {
  creatorOffersTable,
  creatorSubscriptionsTable,
  db,
  ledgerEntriesTable,
  postLikesTable,
  postsTable,
  profilesTable,
  videoLikesTable,
  videoViewEventsTable,
  videosTable,
  walletsTable,
  usersTable,
} from "@workspace/db";
import { optionalAuth, requireAuth } from "../lib/auth";
import { getUncachableStripeClient } from "../stripeClient";
import { getOfferForCreator, recordLedgerEntry, upsertCreatorSubscription, verifyAndRecordCheckout } from "../economyService";

const router: IRouter = Router();

function amount(value: unknown) {
  return Number(value ?? 0);
}

router.get("/economy/studio", requireAuth, async (req, res): Promise<void> => {
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  if (!profile) { res.status(404).json({ error: "Profile not found" }); return; }
  const videos = await db.select().from(videosTable).where(eq(videosTable.creatorId, profile.id)).orderBy(desc(videosTable.createdAt));
  const [postCount, postLikes, videoLikes] = await Promise.all([
    db.select({ count: count() }).from(postsTable).where(eq(postsTable.authorId, profile.id)),
    db.select({ count: count() }).from(postLikesTable)
      .innerJoin(postsTable, eq(postsTable.id, postLikesTable.postId))
      .where(eq(postsTable.authorId, profile.id)),
    db.select({ count: count() }).from(videoLikesTable)
      .innerJoin(videosTable, eq(videosTable.id, videoLikesTable.videoId))
      .where(eq(videosTable.creatorId, profile.id)),
  ]);
  const performance = await Promise.all(videos.map(async (video) => {
    const [stats] = await db.select({
      watchTimeSeconds: sql<number>`coalesce(sum(${videoViewEventsTable.watchSeconds}), 0)`,
      audienceReach: sql<number>`count(distinct ${videoViewEventsTable.viewerId})`,
    }).from(videoViewEventsTable).where(eq(videoViewEventsTable.videoId, video.id));
    return {
      id: video.id,
      title: video.title,
      views: video.viewsCount,
      watchTimeSeconds: amount(stats?.watchTimeSeconds),
      audienceReach: amount(stats?.audienceReach),
    };
  }));
  const [audience] = videos.length ? await db.select({
    uniqueViewers: sql<number>`count(distinct ${videoViewEventsTable.viewerId})`,
  }).from(videoViewEventsTable).where(inArray(videoViewEventsTable.videoId, videos.map((video) => video.id))) : [{ uniqueViewers: 0 }];
  res.json({
    totalViews: videos.reduce((sum, video) => sum + video.viewsCount, 0),
    watchTimeSeconds: performance.reduce((sum, video) => sum + video.watchTimeSeconds, 0),
    audienceReach: amount(audience?.uniqueViewers),
    publishedVideos: videos.length,
    publishedPosts: postCount[0]?.count ?? 0,
    totalLikes: (postLikes[0]?.count ?? 0) + (videoLikes[0]?.count ?? 0),
    topVideos: performance.sort((a, b) => b.views - a.views).slice(0, 10),
  });
});

router.post("/economy/videos/:id/view", requireAuth, async (req, res): Promise<void> => {
  const params = RecordVideoViewParams.safeParse(req.params);
  const body = RecordVideoViewBody.safeParse(req.body);
  if (!params.success || !body.success) { res.status(400).json({ error: "Invalid view event" }); return; }
  const [video] = await db.select({ id: videosTable.id, creatorId: videosTable.creatorId }).from(videosTable).where(eq(videosTable.id, params.data.id));
  if (!video) { res.status(404).json({ error: "Video not found" }); return; }
  const [creator] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, video.creatorId));
  if (creator?.userId === req.userId) { res.json({ active: false, count: 0 }); return; }
  const inserted = await db.insert(videoViewEventsTable).values({
    videoId: video.id,
    viewerId: req.userId!,
    watchSeconds: body.data.watchSeconds,
  }).onConflictDoNothing().returning();
  if (inserted.length) {
    await db.update(videosTable).set({ viewsCount: sql`${videosTable.viewsCount} + 1` }).where(eq(videosTable.id, video.id));
  }
  res.status(inserted.length ? 201 : 200).json({ active: inserted.length > 0, count: inserted.length });
});

router.get("/economy/wallet", requireAuth, async (req, res): Promise<void> => {
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  const entries = wallet ? await db.select().from(ledgerEntriesTable).where(eq(ledgerEntriesTable.walletId, wallet.id)).orderBy(desc(ledgerEntriesTable.createdAt)).limit(100) : [];
  const balances = wallet ? (await db.select({
    available: sql<number>`coalesce(sum(case when ${ledgerEntriesTable.status} in ('available', 'paid') then ${ledgerEntriesTable.amount} else 0 end), 0)`,
    pending: sql<number>`coalesce(sum(case when ${ledgerEntriesTable.status} = 'pending' then ${ledgerEntriesTable.amount} else 0 end), 0)`,
  }).from(ledgerEntriesTable).where(eq(ledgerEntriesTable.walletId, wallet.id)))[0] : null;
  res.json({
    currency: "usd",
    availableBalanceMinor: amount(balances?.available),
    pendingEarningsMinor: amount(balances?.pending),
    transactions: entries.map((entry) => ({
      id: entry.id,
      entryType: entry.entryType,
      status: entry.status,
      amountMinor: entry.amount,
      currency: entry.currency,
      description: entry.description,
      createdAt: entry.createdAt,
    })),
  });
});

router.get("/economy/transactions", requireAuth, async (req, res): Promise<void> => {
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, req.userId!));
  const entries = wallet ? await db.select().from(ledgerEntriesTable).where(eq(ledgerEntriesTable.walletId, wallet.id)).orderBy(desc(ledgerEntriesTable.createdAt)).limit(100) : [];
  res.json(entries.map((entry) => ({
    id: entry.id,
    entryType: entry.entryType,
    status: entry.status,
    amountMinor: entry.amount,
    currency: entry.currency,
    description: entry.description,
    createdAt: entry.createdAt,
  })));
});

router.post("/economy/offers", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateCreatorOfferBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  if (!profile || !profile.isCreator) { res.status(403).json({ error: "Creator profile required" }); return; }
  const [existing] = await db.select().from(creatorOffersTable).where(eq(creatorOffersTable.creatorId, req.userId!));
  if (existing) { res.status(409).json({ error: "A subscription offer already exists" }); return; }
  const stripe = await getUncachableStripeClient();
  const product = await stripe.products.create({ name: parsed.data.name, description: parsed.data.description, metadata: { creator_user_id: req.userId!, kind: "babloshare_creator_subscription" } });
  const price = await stripe.prices.create({ product: product.id, unit_amount: parsed.data.amountMinor, currency: "usd", recurring: { interval: parsed.data.interval }, metadata: { creator_user_id: req.userId! } });
  await db.insert(creatorOffersTable).values({ creatorId: req.userId!, stripeProductId: product.id, stripePriceId: price.id });
  res.status(201).json({ creatorUsername: profile.username, name: product.name, description: product.description ?? "", priceId: price.id, amountMinor: price.unit_amount ?? parsed.data.amountMinor, currency: "usd", interval: parsed.data.interval, active: true });
});

router.get("/economy/offers/:username", optionalAuth, async (req, res): Promise<void> => {
  const parsed = GetCreatorOfferParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.username, parsed.data.username.toLowerCase()));
  if (!profile) { res.status(404).json({ error: "Creator not found" }); return; }
  const offer = await getOfferForCreator(profile.userId);
  if (!offer) { res.status(404).json({ error: "Creator has no active subscription offer" }); return; }
  res.json({ ...offer, creatorUsername: profile.username });
});

async function tipPrice(stripe: Awaited<ReturnType<typeof getUncachableStripeClient>>, amountMinor: number) {
  const products = await stripe.products.search({ query: "name:'BABLOSHARE creator tip' AND active:'true'" });
  const product = products.data[0] ?? await stripe.products.create({ name: "BABLOSHARE creator tip", description: "A one-time tip to a BABLOSHARE creator", metadata: { kind: "babloshare_tip" } });
  return stripe.prices.create({ product: product.id, unit_amount: amountMinor, currency: "usd", metadata: { kind: "babloshare_tip" } });
}

router.post("/economy/tips/checkout", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateTipCheckoutBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [creator] = await db.select().from(profilesTable).where(eq(profilesTable.username, parsed.data.creatorUsername.toLowerCase()));
  if (!creator || creator.userId === req.userId) { res.status(404).json({ error: "Creator not found" }); return; }
  const stripe = await getUncachableStripeClient();
  const price = await tipPrice(stripe, parsed.data.amountMinor);
  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    line_items: [{ price: price.id, quantity: 1 }],
    customer_email: (await db.select({ email: usersTable.email }).from(usersTable).where(eq(usersTable.id, req.userId!)))[0]?.email,
    success_url: `${req.protocol}://${req.get("host")}/profile/${creator.username}?tip_session={CHECKOUT_SESSION_ID}`,
    cancel_url: `${req.protocol}://${req.get("host")}/profile/${creator.username}?tip_cancelled=1`,
    metadata: { economy_type: "tip", creator_user_id: creator.userId, subscriber_user_id: req.userId!, ...(parsed.data.message ? { message: parsed.data.message } : {}) },
  });
  if (!session.url) { res.status(502).json({ error: "Stripe did not return a checkout URL" }); return; }
  res.status(201).json({ sessionId: session.id, checkoutUrl: session.url });
});

router.post("/economy/subscriptions/checkout", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateSubscriptionCheckoutBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [creator] = await db.select().from(profilesTable).where(eq(profilesTable.username, parsed.data.creatorUsername.toLowerCase()));
  if (!creator || creator.userId === req.userId) { res.status(404).json({ error: "Creator not found" }); return; }
  const offer = await getOfferForCreator(creator.userId);
  if (!offer) { res.status(404).json({ error: "Creator has no active subscription offer" }); return; }
  const stripe = await getUncachableStripeClient();
  const user = (await db.select({ email: usersTable.email }).from(usersTable).where(eq(usersTable.id, req.userId!)))[0];
  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    line_items: [{ price: offer.priceId, quantity: 1 }],
    customer_email: user?.email,
    success_url: `${req.protocol}://${req.get("host")}/profile/${creator.username}?subscription_session={CHECKOUT_SESSION_ID}`,
    cancel_url: `${req.protocol}://${req.get("host")}/profile/${creator.username}?subscription_cancelled=1`,
    metadata: { economy_type: "subscription", creator_user_id: creator.userId, subscriber_user_id: req.userId! },
    subscription_data: { metadata: { creator_user_id: creator.userId, subscriber_user_id: req.userId! } },
  });
  if (!session.url) { res.status(502).json({ error: "Stripe did not return a checkout URL" }); return; }
  res.status(201).json({ sessionId: session.id, checkoutUrl: session.url });
});

router.post("/economy/checkout/:sessionId/confirm", requireAuth, async (req, res): Promise<void> => {
  const parsed = ConfirmEconomyCheckoutParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  res.json(await verifyAndRecordCheckout(parsed.data.sessionId, req.userId!));
});

router.get("/economy/subscriptions", requireAuth, async (req, res): Promise<void> => {
  const rows = await db.select({ subscription: creatorSubscriptionsTable, profile: profilesTable })
    .from(creatorSubscriptionsTable)
    .innerJoin(profilesTable, eq(profilesTable.userId, creatorSubscriptionsTable.creatorId))
    .where(eq(creatorSubscriptionsTable.subscriberId, req.userId!))
    .orderBy(desc(creatorSubscriptionsTable.createdAt));
  res.json(rows.map(({ subscription, profile }) => ({ creatorUsername: profile.username, status: subscription.status, currentPeriodEnd: subscription.currentPeriodEnd })));
});

export default router;