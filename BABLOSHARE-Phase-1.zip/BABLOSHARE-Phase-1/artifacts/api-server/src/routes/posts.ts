import { and, count, desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreatePostBody,
  CreatePostCommentBody,
  CreatePostCommentParams,
  DeletePostParams,
  ListPostCommentsParams,
  ListPostsQueryParams,
  TogglePostLikeParams,
  UpdatePostBody,
  UpdatePostParams,
} from "@workspace/api-zod";
import {
  db,
  postCommentsTable,
  postLikesTable,
  postsTable,
  profilesTable,
  usersTable,
} from "@workspace/db";
import { optionalAuth, requireAuth } from "../lib/auth";
import { creatorDto } from "../lib/present";
import { recordNotification } from "../lib/notifications";
import { MediaValidationError, validateStoredMedia } from "../lib/mediaValidation";

const router: IRouter = Router();
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

async function postDto(post: typeof postsTable.$inferSelect, viewerId?: string) {
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.id, post.authorId));
  if (!profile) throw new Error("Post author profile not found");
  const [likes, comments, viewerLike] = await Promise.all([
    db.select({ count: count() }).from(postLikesTable).where(eq(postLikesTable.postId, post.id)),
    db.select({ count: count() }).from(postCommentsTable).where(eq(postCommentsTable.postId, post.id)),
    viewerId
      ? db.select({ userId: postLikesTable.userId }).from(postLikesTable).where(and(eq(postLikesTable.postId, post.id), eq(postLikesTable.userId, viewerId)))
      : Promise.resolve([]),
  ]);
  return {
    id: post.id,
    content: post.content,
    mediaUrl: post.mediaUrl,
    mediaType: post.mediaType as "image" | "video" | null,
    createdAt: post.createdAt,
    author: await creatorDto(profile),
    likeCount: likes[0]?.count ?? 0,
    commentCount: comments[0]?.count ?? 0,
    isLiked: viewerLike.length > 0,
  };
}

async function postComments(postId: string) {
  const comments = await db.select({
    comment: postCommentsTable,
    profile: profilesTable,
  }).from(postCommentsTable)
    .innerJoin(usersTable, eq(usersTable.id, postCommentsTable.userId))
    .innerJoin(profilesTable, eq(profilesTable.userId, usersTable.id))
    .where(eq(postCommentsTable.postId, postId))
    .orderBy(desc(postCommentsTable.createdAt));
  return Promise.all(comments.map(async ({ comment, profile }) => ({
    id: comment.id,
    postId: comment.postId,
    content: comment.content,
    createdAt: comment.createdAt,
    author: await creatorDto(profile),
  })));
}

router.get("/posts", optionalAuth, async (req, res): Promise<void> => {
  const parsed = ListPostsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const posts = await db.select().from(postsTable).orderBy(desc(postsTable.createdAt))
    .limit(parsed.data.limit).offset(parsed.data.offset);
  res.json(await Promise.all(posts.map((post) => postDto(post, req.userId))));
});

router.post("/posts", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreatePostBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const content = parsed.data.content?.trim() ?? "";
  const mediaUrl = parsed.data.mediaUrl ?? null;
  const mediaType = parsed.data.mediaType ?? null;
  if (!content && !mediaUrl) { res.status(400).json({ error: "Add a message or choose a photo or video." }); return; }
  if (mediaUrl && (!mediaType || !["image", "video"].includes(mediaType))) {
    res.status(400).json({ error: "Choose a photo or video from your device." }); return;
  }
  if (!mediaUrl && mediaType) { res.status(400).json({ error: "Media type requires an uploaded file." }); return; }
  if (mediaUrl && mediaType) {
    try { await validateStoredMedia(mediaUrl, req.userId!, mediaType, false); }
    catch (error) {
      res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
      return;
    }
  }
  const [profile] = await db.select({ id: profilesTable.id }).from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  if (!profile) { res.status(404).json({ error: "Profile not found" }); return; }
  const [post] = await db.insert(postsTable).values({ authorId: profile.id, content, mediaUrl, mediaType }).returning();
  res.status(201).json(await postDto(post, req.userId));
});

router.patch("/posts/:id", requireAuth, async (req, res): Promise<void> => {
  const params = UpdatePostParams.safeParse(req.params);
  const body = UpdatePostBody.safeParse(req.body);
  if (!params.success || !body.success || !uuidPattern.test(params.data.id)) {
    res.status(400).json({ error: "Invalid post update" }); return;
  }
  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) { res.status(404).json({ error: "Post not found" }); return; }
  const [author] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, post.authorId));
  if (author?.userId !== req.userId) { res.status(403).json({ error: "Only the author can edit this post" }); return; }
  const content = body.data.content === undefined ? post.content : body.data.content.trim();
  const mediaUrl = body.data.mediaUrl === undefined ? post.mediaUrl : body.data.mediaUrl;
  const storedType = post.mediaType === "image" || post.mediaType === "video" ? post.mediaType : null;
  const mediaType = body.data.mediaType === undefined ? storedType : body.data.mediaType;
  if (!content && !mediaUrl) { res.status(400).json({ error: "A post must contain text or media." }); return; }
  if (mediaUrl) {
    if (!mediaType || !["image", "video"].includes(mediaType)) { res.status(400).json({ error: "Choose a valid uploaded media type." }); return; }
    const validMediaType = mediaType === "image" || mediaType === "video" ? mediaType : null;
    if (!validMediaType) { res.status(400).json({ error: "Choose a valid uploaded media type." }); return; }
    try { await validateStoredMedia(mediaUrl, req.userId!, validMediaType, false); }
    catch (error) {
      res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
      return;
    }
  }
  const [updated] = await db.update(postsTable).set({ content, mediaUrl: mediaUrl ?? null, mediaType: mediaUrl ? mediaType : null })
    .where(eq(postsTable.id, post.id)).returning();
  res.json(await postDto(updated, req.userId));
});

router.delete("/posts/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeletePostParams.safeParse(req.params);
  if (!params.success || !uuidPattern.test(params.data.id)) { res.status(400).json({ error: "Invalid post id" }); return; }
  const [post] = await db.select().from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) { res.status(404).json({ error: "Post not found" }); return; }
  const [author] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, post.authorId));
  if (author?.userId !== req.userId) { res.status(403).json({ error: "Only the author can delete this post" }); return; }
  await db.delete(postsTable).where(eq(postsTable.id, post.id));
  res.status(204).end();
});

router.post("/posts/:id/like", requireAuth, async (req, res): Promise<void> => {
  const params = TogglePostLikeParams.safeParse(req.params);
  if (!params.success || !uuidPattern.test(params.data.id)) { res.status(400).json({ error: "Invalid post id" }); return; }
  const [post] = await db.select({ id: postsTable.id, authorId: postsTable.authorId }).from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) { res.status(404).json({ error: "Post not found" }); return; }
  const condition = and(eq(postLikesTable.userId, req.userId!), eq(postLikesTable.postId, post.id));
  const [existing] = await db.select().from(postLikesTable).where(condition);
  if (existing) await db.delete(postLikesTable).where(condition);
  else {
    const inserted = await db.insert(postLikesTable).values({ userId: req.userId!, postId: post.id }).onConflictDoNothing().returning();
    if (inserted.length) {
      const [owner] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, post.authorId));
      if (owner) try {
        await recordNotification({ recipientId: owner.userId, actorId: req.userId!, type: "post_like", entityType: "post", entityId: post.id });
      } catch (error) { req.log.error({ err: error }, "notification_write_failed"); }
    }
  }
  const [likes] = await db.select({ count: count() }).from(postLikesTable).where(eq(postLikesTable.postId, post.id));
  res.json({ active: !existing, count: likes?.count ?? 0 });
});

router.get("/posts/:id/comments", async (req, res): Promise<void> => {
  const params = ListPostCommentsParams.safeParse(req.params);
  if (!params.success || !uuidPattern.test(params.data.id)) { res.status(400).json({ error: "Invalid post id" }); return; }
  const [post] = await db.select({ id: postsTable.id, authorId: postsTable.authorId }).from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) { res.status(404).json({ error: "Post not found" }); return; }
  res.json(await postComments(post.id));
});

router.post("/posts/:id/comments", requireAuth, async (req, res): Promise<void> => {
  const params = CreatePostCommentParams.safeParse(req.params);
  const body = CreatePostCommentBody.safeParse(req.body);
  if (!params.success || !body.success || !uuidPattern.test(params.data.id)) {
    res.status(400).json({ error: "Invalid post comment" }); return;
  }
  const [post] = await db.select({ id: postsTable.id, authorId: postsTable.authorId }).from(postsTable).where(eq(postsTable.id, params.data.id));
  if (!post) { res.status(404).json({ error: "Post not found" }); return; }
  const [comment] = await db.insert(postCommentsTable).values({
    postId: post.id,
    userId: req.userId!,
    content: body.data.content.trim(),
  }).returning();
  const [owner] = await db.select({ userId: profilesTable.userId }).from(profilesTable).where(eq(profilesTable.id, post.authorId));
  if (owner) try {
    await recordNotification({ recipientId: owner.userId, actorId: req.userId!, type: "post_comment", entityType: "post", entityId: post.id });
  } catch (error) { req.log.error({ err: error }, "notification_write_failed"); }
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  res.status(201).json({
    id: comment.id,
    postId: comment.postId,
    content: comment.content,
    createdAt: comment.createdAt,
    author: await creatorDto(profile),
  });
});

export default router;
