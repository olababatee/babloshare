import { desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  ListAdminReportsResponse,
  ListAdminUsersResponse,
  ReviewAdminReportBody,
  ReviewAdminReportParams,
  ReviewAdminReportResponse,
  UpdateAdminUserStatusParams,
  UpdateAdminUserStatusBody,
  UpdateAdminUserStatusResponse,
} from "@workspace/api-zod";
import {
  conversationReportsTable,
  conversationsTable,
  db,
  moderationActionsTable,
  profilesTable,
  usersTable,
} from "@workspace/db";
import type { Request, Response, NextFunction } from "express";
import { requireAuth } from "../lib/auth";
import { creatorDto } from "../lib/present";

const router: IRouter = Router();
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  const [user] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, req.userId!));
  if (user?.role !== "admin") {
    res.status(403).json({ error: "Administrator access required" });
    return;
  }
  next();
}

router.get("/admin/reports", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select({
    report: conversationReportsTable,
    conversation: conversationsTable,
    profile: profilesTable,
  }).from(conversationReportsTable)
    .innerJoin(conversationsTable, eq(conversationsTable.id, conversationReportsTable.conversationId))
    .innerJoin(usersTable, eq(usersTable.id, conversationReportsTable.reporterId))
    .innerJoin(profilesTable, eq(profilesTable.userId, usersTable.id))
    .orderBy(desc(conversationReportsTable.createdAt))
    .limit(100);
  const result = await Promise.all(rows.map(async ({ report, conversation, profile }) => ({
    id: report.id,
    conversationTitle: conversation.title,
    reason: report.reason,
    status: report.status,
    createdAt: report.createdAt,
    reviewedAt: report.reviewedAt,
    reporter: await creatorDto(profile),
  })));
  res.json(ListAdminReportsResponse.parse(result));
});

router.patch("/admin/reports/:id", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const params = ReviewAdminReportParams.safeParse(req.params);
  const body = ReviewAdminReportBody.safeParse(req.body);
  if (!params.success || !body.success || !uuidPattern.test(params.data.id)) {
    res.status(400).json({ error: "Invalid moderation request" });
    return;
  }
  const [updated] = await db.update(conversationReportsTable)
    .set({ status: body.data.status, reviewedBy: req.userId!, reviewedAt: new Date() })
    .where(eq(conversationReportsTable.id, params.data.id))
    .returning();
  if (!updated) { res.status(404).json({ error: "Report not found" }); return; }
  const [conversation] = await db.select({ title: conversationsTable.title })
    .from(conversationsTable).where(eq(conversationsTable.id, updated.conversationId));
  const [reporter] = await db.select().from(profilesTable)
    .innerJoin(usersTable, eq(usersTable.id, profilesTable.userId))
    .where(eq(usersTable.id, updated.reporterId));
  if (!conversation || !reporter) { res.status(404).json({ error: "Report details no longer exist" }); return; }
  res.json(ReviewAdminReportResponse.parse({
    id: updated.id,
    conversationTitle: conversation.title,
    reason: updated.reason,
    status: updated.status,
    createdAt: updated.createdAt,
    reviewedAt: updated.reviewedAt,
    reporter: await creatorDto(reporter.profiles),
  }));
});

router.get("/admin/users", requireAuth, requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select({
    user: usersTable,
    profile: profilesTable,
  }).from(usersTable)
    .innerJoin(profilesTable, eq(profilesTable.userId, usersTable.id))
    .orderBy(desc(usersTable.createdAt))
    .limit(100);
  res.json(ListAdminUsersResponse.parse(rows.map(({ user, profile }) => ({
    id: user.id,
    username: profile.username,
    displayName: profile.displayName,
    role: user.role,
    accountStatus: user.accountStatus,
    createdAt: user.createdAt,
  }))));
});

router.patch("/admin/users/:id/status", requireAuth, requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminUserStatusParams.safeParse(req.params);
  const body = UpdateAdminUserStatusBody.safeParse(req.body);
  if (!params.success || !body.success || !uuidPattern.test(params.data.id)) {
    res.status(400).json({ error: "Invalid account moderation request" });
    return;
  }
  if (params.data.id === req.userId) { res.status(400).json({ error: "Administrators cannot change their own account status" }); return; }
  const [target] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.id));
  if (!target) { res.status(404).json({ error: "Account not found" }); return; }
  if (target.role === "admin") { res.status(403).json({ error: "Administrator accounts are managed outside this dashboard" }); return; }
  const [updated] = await db.transaction(async (tx) => {
    const updatedUsers = await tx.update(usersTable).set({ accountStatus: body.data.accountStatus })
      .where(eq(usersTable.id, target.id)).returning();
    await tx.insert(moderationActionsTable).values({
      adminId: req.userId!,
      targetUserId: target.id,
      action: body.data.accountStatus === "suspended" ? "account_suspended" : "account_reactivated",
      reason: body.data.reason.trim(),
    });
    return updatedUsers;
  });
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, updated.id));
  if (!profile) { res.status(404).json({ error: "Account profile not found" }); return; }
  res.json(UpdateAdminUserStatusResponse.parse({
    id: updated.id,
    username: profile.username,
    displayName: profile.displayName,
    role: updated.role,
    accountStatus: updated.accountStatus,
    createdAt: updated.createdAt,
  }));
});

export default router;
