import { and, asc, count, desc, eq, gt, ilike, inArray, isNull, not, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateConversationBody,
  CreateGroupBody,
  CreateGroupPostBody,
  CreateGroupPostParams,
  CreatePageBody,
  CreateStoryBody,
  GetGroupParams,
  GetPageParams,
  ListGroupPostsParams,
  ListGroupsQueryParams,
  ListMessagesParams,
  ListPagesQueryParams,
  MarkConversationReadParams,
  MarkStoryViewedParams,
  ReactToMessageBody,
  ReactToMessageParams,
  ReportConversationBody,
  ReportConversationParams,
  SendMessageBody,
  SendMessageParams,
  TogglePageFollowParams,
  UpdateGroupMembershipBody,
  UpdateGroupMembershipParams,
  UpdatePageAdminBody,
  UpdatePageAdminParams,
} from "@workspace/api-zod";
import {
  conversationsTable,
  conversationMembersTable,
  conversationReportsTable,
  db,
  followsTable,
  groupMembersTable,
  groupPostsTable,
  groupsTable,
  messageReactionsTable,
  messagesTable,
  pageAdminsTable,
  pageFollowersTable,
  pagesTable,
  profilesTable,
  storiesTable,
  storyViewsTable,
  usersTable,
  videosTable,
} from "@workspace/db";
import { optionalAuth, requireAuth } from "../lib/auth";
import { creatorDto, profileDto, videoDto } from "../lib/present";
import { MediaValidationError, validateStoredMedia } from "../lib/mediaValidation";

const router: IRouter = Router();

async function groupDto(group: typeof groupsTable.$inferSelect, viewerId?: string) {
  const [members, viewerMembership] = await Promise.all([
    db.select({ count: count() }).from(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.status, "active"))),
    viewerId ? db.select().from(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, viewerId))) : Promise.resolve([]),
  ]);
  const membership = viewerMembership[0];
  return {
    id: group.id,
    name: group.name,
    description: group.description,
    groupType: group.groupType,
    creatorId: group.creatorId,
    createdAt: group.createdAt,
    memberCount: members[0]?.count ?? 0,
    viewerRole: membership?.status === "active" ? membership.role : null,
    accessState: membership?.status === "requested" ? "requested" : membership?.status === "active" ? "member" : "none",
  };
}

async function pageDto(page: typeof pagesTable.$inferSelect, viewerId?: string) {
  const [followers, admin] = await Promise.all([
    db.select({ count: count() }).from(pageFollowersTable).where(eq(pageFollowersTable.pageId, page.id)),
    viewerId ? db.select().from(pageAdminsTable).where(and(eq(pageAdminsTable.pageId, page.id), eq(pageAdminsTable.userId, viewerId))) : Promise.resolve([]),
  ]);
  const following = viewerId ? await db.select().from(pageFollowersTable).where(and(eq(pageFollowersTable.pageId, page.id), eq(pageFollowersTable.userId, viewerId))) : [];
  return {
    id: page.id,
    ownerId: page.ownerId,
    username: page.username,
    pageType: page.pageType,
    bio: page.bio,
    avatarUrl: page.avatarUrl,
    coverUrl: page.coverUrl,
    isVerified: page.isVerified,
    followerCount: followers[0]?.count ?? 0,
    isFollowing: following.length > 0,
    adminRole: admin[0]?.role ?? null,
  };
}

async function participantDto(userId: string) {
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, userId));
  if (!profile) return { id: userId, username: "unknown", displayName: "Unknown member", avatarUrl: null };
  return { id: profile.userId, username: profile.username, displayName: profile.displayName, avatarUrl: profile.avatarUrl };
}

async function messageDto(message: typeof messagesTable.$inferSelect) {
  const [reactions] = await Promise.all([
    db.select({ reaction: messageReactionsTable.reaction }).from(messageReactionsTable).where(eq(messageReactionsTable.messageId, message.id)),
  ]);
  return {
    id: message.id,
    conversationId: message.conversationId,
    sender: await participantDto(message.senderId),
    content: message.content,
    mediaUrl: message.mediaUrl,
    mediaType: message.mediaType as "image" | "video" | null,
    createdAt: message.createdAt,
    readAt: message.readAt,
    reactions: reactions.map((item) => item.reaction),
  };
}

async function requireConversationMember(conversationId: string, userId: string) {
  const [member] = await db.select().from(conversationMembersTable).where(and(eq(conversationMembersTable.conversationId, conversationId), eq(conversationMembersTable.userId, userId)));
  return member;
}

router.get("/groups", optionalAuth, async (req, res): Promise<void> => {
  const parsed = ListGroupsQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const groups = await db.select().from(groupsTable)
    .where(parsed.data.q ? ilike(groupsTable.name, `%${parsed.data.q}%`) : undefined)
    .orderBy(desc(groupsTable.createdAt))
    .limit(parsed.data.limit ?? 24);
  res.json(await Promise.all(groups.map((group) => groupDto(group, req.userId))));
});

router.post("/groups", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateGroupBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [group] = await db.insert(groupsTable).values({ ...parsed.data, creatorId: req.userId! }).returning();
  await db.insert(groupMembersTable).values({ groupId: group.id, userId: req.userId!, role: "admin", status: "active" });
  res.status(201).json(await groupDto(group, req.userId));
});

router.get("/groups/:id", optionalAuth, async (req, res): Promise<void> => {
  const parsed = GetGroupParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, parsed.data.id));
  if (!group) { res.status(404).json({ error: "Group not found" }); return; }
  const membership = req.userId ? await requireGroupAccess(group.id, req.userId) : null;
  if (group.groupType !== "public" && !membership) { res.status(403).json({ error: "Membership required" }); return; }
  res.json(await groupDto(group, req.userId));
});

async function requireGroupAccess(groupId: string, userId: string) {
  const [member] = await db.select().from(groupMembersTable).where(and(eq(groupMembersTable.groupId, groupId), eq(groupMembersTable.userId, userId), eq(groupMembersTable.status, "active")));
  return member;
}

router.post("/groups/:id/membership", requireAuth, async (req, res): Promise<void> => {
  const params = UpdateGroupMembershipParams.safeParse(req.params);
  const body = UpdateGroupMembershipBody.safeParse(req.body);
  if (!params.success || !body.success) { const error = !params.success ? params.error.message : body.success ? "Invalid request body" : body.error.message; res.status(400).json({ error }); return; }
  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, params.data.id));
  if (!group) { res.status(404).json({ error: "Group not found" }); return; }
  const action = body.data.action;
  const targetUserId = body.data.userId ?? req.userId!;
  const [existing] = await db.select().from(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, targetUserId)));
  if (action === "approve" || action === "remove") {
    const admin = await requireGroupAccess(group.id, req.userId!);
    if (!admin || (admin.role !== "admin" && admin.role !== "moderator")) { res.status(403).json({ error: "Moderator permission required" }); return; }
    if (action === "approve") await db.update(groupMembersTable).set({ status: "active", role: "member" }).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, targetUserId)));
    else await db.delete(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, targetUserId)));
  } else if (action === "leave") {
    await db.delete(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, req.userId!)));
  } else if (action === "join" || action === "request") {
    const shouldActivate = group.groupType === "public" && action === "join";
    if (!existing) await db.insert(groupMembersTable).values({ groupId: group.id, userId: req.userId!, role: "member", status: shouldActivate ? "active" : "requested" });
    else if (existing.status === "requested" && shouldActivate) await db.update(groupMembersTable).set({ status: "active" }).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, req.userId!)));
  }
  const [updated] = await db.select().from(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.userId, req.userId!)));
  const members = await db.select().from(groupMembersTable).where(and(eq(groupMembersTable.groupId, group.id), eq(groupMembersTable.status, "active")));
  res.json({ active: updated?.status === "active", state: updated?.status === "active" ? "member" : updated?.status === "requested" ? "requested" : "none", role: updated?.status === "active" ? updated.role : null, memberCount: members.length });
});

router.get("/groups/:id/posts", optionalAuth, async (req, res): Promise<void> => {
  const parsed = ListGroupPostsParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [group] = await db.select().from(groupsTable).where(eq(groupsTable.id, parsed.data.id));
  if (!group) { res.status(404).json({ error: "Group not found" }); return; }
  if (group.groupType !== "public" && (!req.userId || !(await requireGroupAccess(group.id, req.userId)))) { res.status(403).json({ error: "Membership required" }); return; }
  const posts = await db.select().from(groupPostsTable).where(eq(groupPostsTable.groupId, group.id)).orderBy(desc(groupPostsTable.createdAt));
  const result = await Promise.all(posts.map(async (post) => {
    const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, post.authorId));
    const video = post.videoId ? (await db.select().from(videosTable).where(eq(videosTable.id, post.videoId)))[0] : null;
    return { id: post.id, groupId: post.groupId, postType: post.postType, content: post.content, createdAt: post.createdAt, author: profile ? await creatorDto(profile) : { id: post.authorId, username: "unknown", displayName: "Unknown member", avatarUrl: null, isVerified: false, isCreator: false }, video: video ? await videoDto(video, req.userId) : null };
  }));
  res.json(result);
});

router.post("/groups/:id/posts", requireAuth, async (req, res): Promise<void> => {
  const params = CreateGroupPostParams.safeParse(req.params);
  const body = CreateGroupPostBody.safeParse(req.body);
  if (!params.success || !body.success) { const error = !params.success ? params.error.message : body.success ? "Invalid request body" : body.error.message; res.status(400).json({ error }); return; }
  const member = await requireGroupAccess(params.data.id, req.userId!);
  if (!member) { res.status(403).json({ error: "Active group membership required" }); return; }
  const [post] = await db.insert(groupPostsTable).values({ ...body.data, groupId: params.data.id, authorId: req.userId!, videoId: body.data.videoId ?? null }).returning();
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  const video = post.videoId ? (await db.select().from(videosTable).where(eq(videosTable.id, post.videoId)))[0] : null;
  res.status(201).json({ id: post.id, groupId: post.groupId, postType: post.postType, content: post.content, createdAt: post.createdAt, author: await creatorDto(profile), video: video ? await videoDto(video, req.userId) : null });
});

router.get("/pages", optionalAuth, async (req, res): Promise<void> => {
  const parsed = ListPagesQueryParams.safeParse(req.query);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const pages = await db.select().from(pagesTable).where(parsed.data.q ? or(ilike(pagesTable.username, `%${parsed.data.q}%`), ilike(pagesTable.bio, `%${parsed.data.q}%`)) : undefined).orderBy(desc(pagesTable.createdAt)).limit(parsed.data.limit ?? 24);
  res.json(await Promise.all(pages.map((page) => pageDto(page, req.userId))));
});

router.post("/pages", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreatePageBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  try {
    if (parsed.data.avatarUrl) await validateStoredMedia(parsed.data.avatarUrl, req.userId!, "image");
    if (parsed.data.coverUrl) await validateStoredMedia(parsed.data.coverUrl, req.userId!, "image");
  } catch (error) {
    res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
    return;
  }
  const [existing] = await db.select({ id: pagesTable.id }).from(pagesTable).where(eq(pagesTable.username, parsed.data.username.toLowerCase()));
  if (existing) { res.status(409).json({ error: "Page username is already in use" }); return; }
  const [page] = await db.insert(pagesTable).values({ ...parsed.data, username: parsed.data.username.toLowerCase(), ownerId: req.userId!, avatarUrl: parsed.data.avatarUrl ?? null, coverUrl: parsed.data.coverUrl ?? null }).returning();
  await db.insert(pageAdminsTable).values({ pageId: page.id, userId: req.userId!, role: "owner" });
  res.status(201).json(await pageDto(page, req.userId));
});

router.get("/pages/:username", optionalAuth, async (req, res): Promise<void> => {
  const parsed = GetPageParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [page] = await db.select().from(pagesTable).where(eq(pagesTable.username, parsed.data.username.toLowerCase()));
  if (!page) { res.status(404).json({ error: "Page not found" }); return; }
  res.json(await pageDto(page, req.userId));
});

router.post("/pages/:username/follow", requireAuth, async (req, res): Promise<void> => {
  const parsed = TogglePageFollowParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const [page] = await db.select().from(pagesTable).where(eq(pagesTable.username, parsed.data.username.toLowerCase()));
  if (!page) { res.status(404).json({ error: "Page not found" }); return; }
  const [existing] = await db.select().from(pageFollowersTable).where(and(eq(pageFollowersTable.pageId, page.id), eq(pageFollowersTable.userId, req.userId!)));
  if (existing) await db.delete(pageFollowersTable).where(and(eq(pageFollowersTable.pageId, page.id), eq(pageFollowersTable.userId, req.userId!)));
  else await db.insert(pageFollowersTable).values({ pageId: page.id, userId: req.userId! });
  const followers = await db.select().from(pageFollowersTable).where(eq(pageFollowersTable.pageId, page.id));
  res.json({ active: !existing, count: followers.length });
});

router.post("/pages/:username/admins", requireAuth, async (req, res): Promise<void> => {
  const params = UpdatePageAdminParams.safeParse(req.params);
  const body = UpdatePageAdminBody.safeParse(req.body);
  if (!params.success || !body.success) { const error = !params.success ? params.error.message : body.success ? "Invalid request body" : body.error.message; res.status(400).json({ error }); return; }
  const [page] = await db.select().from(pagesTable).where(eq(pagesTable.username, params.data.username.toLowerCase()));
  if (!page) { res.status(404).json({ error: "Page not found" }); return; }
  const [admin] = await db.select().from(pageAdminsTable).where(and(eq(pageAdminsTable.pageId, page.id), eq(pageAdminsTable.userId, req.userId!)));
  if (!admin || (admin.role !== "owner" && admin.role !== "admin")) { res.status(403).json({ error: "Page administration permission required" }); return; }
  await db.insert(pageAdminsTable).values({ pageId: page.id, userId: body.data.userId, role: body.data.role }).onConflictDoUpdate({ target: [pageAdminsTable.pageId, pageAdminsTable.userId], set: { role: body.data.role } });
  res.json({ pageId: page.id, userId: body.data.userId, role: body.data.role });
});

router.get("/stories", optionalAuth, async (req, res): Promise<void> => {
  const active = await db.select().from(storiesTable).where(gt(storiesTable.expiresAt, new Date())).orderBy(desc(storiesTable.createdAt));
  const viewerProfile = req.userId ? (await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!)))[0] : null;
  const visible = [];
  for (const story of active) {
    const author = (await db.select().from(profilesTable).where(eq(profilesTable.userId, story.authorId)))[0];
    if (!author) continue;
    let allowed = story.visibility === "public" || story.authorId === req.userId;
    if (!allowed && viewerProfile) {
      const followed = await db.select().from(followsTable).where(and(eq(followsTable.followerId, viewerProfile.id), eq(followsTable.followingId, author.id)));
      allowed = followed.length > 0;
    }
    if (!allowed) continue;
    const viewed = req.userId ? await db.select().from(storyViewsTable).where(and(eq(storyViewsTable.storyId, story.id), eq(storyViewsTable.userId, req.userId!))) : [];
    visible.push({ id: story.id, author: await creatorDto(author), mediaType: story.mediaType, mediaUrl: story.mediaUrl, visibility: story.visibility, expiresAt: story.expiresAt, createdAt: story.createdAt, hasViewed: viewed.length > 0 });
  }
  res.json(visible);
});

router.post("/stories", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateStoryBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  try {
    await validateStoredMedia(parsed.data.mediaUrl, req.userId!, parsed.data.mediaType === "photo" ? "image" : "video");
  } catch (error) {
    res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
    return;
  }
  const [story] = await db.insert(storiesTable).values({ ...parsed.data, authorId: req.userId!, mediaUrl: parsed.data.mediaUrl }).returning();
  const [author] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  res.status(201).json({ id: story.id, author: await creatorDto(author), mediaType: story.mediaType, mediaUrl: story.mediaUrl, visibility: story.visibility, expiresAt: story.expiresAt, createdAt: story.createdAt, hasViewed: false });
});

router.post("/stories/:id/view", requireAuth, async (req, res): Promise<void> => {
  const parsed = MarkStoryViewedParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  await db.insert(storyViewsTable).values({ storyId: parsed.data.id, userId: req.userId! }).onConflictDoNothing();
  res.json({ active: true, count: 1 });
});

router.get("/conversations", requireAuth, async (req, res): Promise<void> => {
  const memberships = await db.select().from(conversationMembersTable).where(eq(conversationMembersTable.userId, req.userId!));
  const result = await Promise.all(memberships.map(async (membership) => {
    const [conversation] = await db.select().from(conversationsTable).where(eq(conversationsTable.id, membership.conversationId));
    if (!conversation) return null;
    const members = await db.select().from(conversationMembersTable).where(eq(conversationMembersTable.conversationId, conversation.id));
    const participants = await Promise.all(members.map((member) => participantDto(member.userId)));
    const [last] = await db.select().from(messagesTable).where(eq(messagesTable.conversationId, conversation.id)).orderBy(desc(messagesTable.createdAt)).limit(1);
    const unread = await db.select().from(messagesTable).where(and(eq(messagesTable.conversationId, conversation.id), not(eq(messagesTable.senderId, req.userId!)), isNull(messagesTable.readAt)));
    return { id: conversation.id, title: conversation.title, isGroup: members.length > 2, updatedAt: conversation.updatedAt, participants, lastMessage: last ? await messageDto(last) : null, unreadCount: unread.length, blocked: Boolean(membership.blockedAt) };
  }));
  res.json(result.filter(Boolean));
});

router.post("/conversations", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateConversationBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const participantIds = [...new Set([req.userId!, ...parsed.data.participantIds])];
  const [conversation] = await db.insert(conversationsTable).values({ title: parsed.data.title ?? "Conversation", createdBy: req.userId! }).returning();
  await db.insert(conversationMembersTable).values(participantIds.map((userId) => ({ conversationId: conversation.id, userId })));
  res.status(201).json({ id: conversation.id, title: conversation.title, isGroup: participantIds.length > 2, updatedAt: conversation.updatedAt, participants: await Promise.all(participantIds.map(participantDto)), lastMessage: null, unreadCount: 0, blocked: false });
});

router.get("/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const parsed = ListMessagesParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const member = await requireConversationMember(parsed.data.id, req.userId!);
  if (!member) { res.status(403).json({ error: "Conversation access required" }); return; }
  const messages = await db.select().from(messagesTable).where(eq(messagesTable.conversationId, parsed.data.id)).orderBy(asc(messagesTable.createdAt));
  res.json(await Promise.all(messages.map(messageDto)));
});

router.post("/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const params = SendMessageParams.safeParse(req.params);
  const body = SendMessageBody.safeParse(req.body);
  if (!params.success || !body.success) { const error = !params.success ? params.error.message : body.success ? "Invalid request body" : body.error.message; res.status(400).json({ error }); return; }
  const member = await requireConversationMember(params.data.id, req.userId!);
  if (!member) { res.status(403).json({ error: "Conversation access required" }); return; }
  if (member.blockedAt) { res.status(403).json({ error: "Conversation is blocked" }); return; }
  const mediaUrl = body.data.mediaUrl ?? null;
  const mediaType = body.data.mediaType ?? null;
  if (!body.data.content.trim() && !mediaUrl) { res.status(400).json({ error: "Write a message or choose a photo or video." }); return; }
  if (mediaUrl && (!mediaType || !["image", "video"].includes(mediaType))) {
    res.status(400).json({ error: "Choose a photo or video from your device." }); return;
  }
  if (!mediaUrl && mediaType) { res.status(400).json({ error: "Media type requires an uploaded file." }); return; }
  if (mediaUrl && mediaType) {
    try { await validateStoredMedia(mediaUrl, req.userId!, mediaType); }
    catch (error) {
      res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
      return;
    }
  }
  const [message] = await db.insert(messagesTable).values({
    conversationId: params.data.id,
    senderId: req.userId!,
    content: body.data.content.trim(),
    mediaUrl,
    mediaType,
  }).returning();
  await db.update(conversationsTable).set({ updatedAt: new Date() }).where(eq(conversationsTable.id, params.data.id));
  res.status(201).json(await messageDto(message));
});

router.post("/conversations/:id/read", requireAuth, async (req, res): Promise<void> => {
  const parsed = MarkConversationReadParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const member = await requireConversationMember(parsed.data.id, req.userId!);
  if (!member) { res.status(403).json({ error: "Conversation access required" }); return; }
  const now = new Date();
  await db.update(conversationMembersTable).set({ lastReadAt: now }).where(and(eq(conversationMembersTable.conversationId, parsed.data.id), eq(conversationMembersTable.userId, req.userId!)));
  await db.update(messagesTable).set({ readAt: now }).where(and(eq(messagesTable.conversationId, parsed.data.id), not(eq(messagesTable.senderId, req.userId!)), isNull(messagesTable.readAt)));
  res.json({ active: true, count: 0 });
});

router.post("/conversations/:id/block", requireAuth, async (req, res): Promise<void> => {
  const parsed = MarkConversationReadParams.safeParse(req.params);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const member = await requireConversationMember(parsed.data.id, req.userId!);
  if (!member) { res.status(403).json({ error: "Conversation access required" }); return; }
  await db.update(conversationMembersTable).set({ blockedAt: new Date() }).where(and(eq(conversationMembersTable.conversationId, parsed.data.id), eq(conversationMembersTable.userId, req.userId!)));
  res.json({ active: true, count: 1 });
});

router.post("/conversations/:id/report", requireAuth, async (req, res): Promise<void> => {
  const params = ReportConversationParams.safeParse(req.params);
  const body = ReportConversationBody.safeParse(req.body);
  if (!params.success || !body.success) { const error = !params.success ? params.error.message : body.success ? "Invalid request body" : body.error.message; res.status(400).json({ error }); return; }
  if (!(await requireConversationMember(params.data.id, req.userId!))) { res.status(403).json({ error: "Conversation access required" }); return; }
  await db.insert(conversationReportsTable).values({ conversationId: params.data.id, reporterId: req.userId!, reason: body.data.reason });
  res.status(201).json({ accepted: true });
});

router.post("/messages/:id/reaction", requireAuth, async (req, res): Promise<void> => {
  const params = ReactToMessageParams.safeParse(req.params);
  const body = ReactToMessageBody.safeParse(req.body);
  if (!params.success || !body.success) { const error = !params.success ? params.error.message : body.success ? "Invalid request body" : body.error.message; res.status(400).json({ error }); return; }
  const [message] = await db.select().from(messagesTable).where(eq(messagesTable.id, params.data.id));
  if (!message || !(await requireConversationMember(message.conversationId, req.userId!))) { res.status(404).json({ error: "Message not found" }); return; }
  const [existing] = await db.select().from(messageReactionsTable).where(and(eq(messageReactionsTable.messageId, message.id), eq(messageReactionsTable.userId, req.userId!), eq(messageReactionsTable.reaction, body.data.reaction)));
  if (existing) await db.delete(messageReactionsTable).where(and(eq(messageReactionsTable.messageId, message.id), eq(messageReactionsTable.userId, req.userId!), eq(messageReactionsTable.reaction, body.data.reaction)));
  else await db.insert(messageReactionsTable).values({ messageId: message.id, userId: req.userId!, reaction: body.data.reaction });
  res.json({ active: !existing, count: 1 });
});

export default router;