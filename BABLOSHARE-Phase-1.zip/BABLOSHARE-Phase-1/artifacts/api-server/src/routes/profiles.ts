import { and, count, desc, eq, ne } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { GetProfileParams, ListProfileVideosParams, ToggleFollowParams, UpdateMyProfileBody } from "@workspace/api-zod";
import { db, followsTable, profilesTable, videosTable } from "@workspace/db";
import { optionalAuth, requireAuth } from "../lib/auth";
import { profileDto, videoDto } from "../lib/present";
import { recordNotification } from "../lib/notifications";
import { MediaValidationError, validateStoredMedia } from "../lib/mediaValidation";

const router: IRouter = Router();

router.patch("/profiles/me", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpdateMyProfileBody.safeParse(req.body);
  if (!parsed.success || !Object.keys(req.body ?? {}).length) {
    res.status(400).json({ error: parsed.success ? "At least one profile field is required" : parsed.error.message });
    return;
  }
  const updates = { ...parsed.data };
  try {
    if (updates.avatarUrl) await validateStoredMedia(updates.avatarUrl, req.userId!, "image");
    if (updates.coverUrl) await validateStoredMedia(updates.coverUrl, req.userId!, "image");
  } catch (error) {
    res.status(400).json({ error: error instanceof MediaValidationError ? error.message : "The media could not be verified." });
    return;
  }
  if (updates.username) {
    updates.username = updates.username.trim().toLowerCase();
    const [existing] = await db.select({ id: profilesTable.id }).from(profilesTable)
      .where(and(eq(profilesTable.username, updates.username), ne(profilesTable.userId, req.userId!)));
    if (existing) { res.status(409).json({ error: "That username is already in use" }); return; }
  }
  const [profile] = await db.update(profilesTable).set(updates)
    .where(eq(profilesTable.userId, req.userId!)).returning();
  if (!profile) { res.status(404).json({ error: "Profile not found" }); return; }
  const [followers, following] = await Promise.all([
    db.select({ count: count() }).from(followsTable).where(eq(followsTable.followingId, profile.id)),
    db.select({ count: count() }).from(followsTable).where(eq(followsTable.followerId, profile.id)),
  ]);
  res.json({
    id: profile.id,
    userId: profile.userId,
    username: profile.username,
    displayName: profile.displayName,
    bio: profile.bio,
    avatarUrl: profile.avatarUrl,
    coverUrl: profile.coverUrl,
    isVerified: profile.isVerified,
    isCreator: profile.isCreator,
    followerCount: followers[0]?.count ?? 0,
    followingCount: following[0]?.count ?? 0,
    isFollowing: false,
  });
});

router.get("/profiles/:username", optionalAuth, async (req, res): Promise<void> => {
  const parsed = GetProfileParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.username, parsed.data.username.trim().toLowerCase()));
  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  res.json(await profileDto(profile, req.userId));
});

router.get("/profiles/:username/videos", optionalAuth, async (req, res): Promise<void> => {
  const parsed = ListProfileVideosParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [profile] = await db.select().from(profilesTable).where(eq(profilesTable.username, parsed.data.username.trim().toLowerCase()));
  if (!profile) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  const videos = await db.select().from(videosTable).where(eq(videosTable.creatorId, profile.id)).orderBy(desc(videosTable.createdAt));
  res.json(await Promise.all(videos.map((video) => videoDto(video, req.userId))));
});

router.post("/profiles/:username/follow", requireAuth, async (req, res): Promise<void> => {
  const parsed = ToggleFollowParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [target] = await db.select().from(profilesTable).where(eq(profilesTable.username, parsed.data.username.trim().toLowerCase()));
  const [viewer] = await db.select().from(profilesTable).where(eq(profilesTable.userId, req.userId!));
  if (!target || !viewer) {
    res.status(404).json({ error: "Profile not found" });
    return;
  }
  if (target.id === viewer.id) {
    res.status(400).json({ error: "You cannot follow yourself" });
    return;
  }
  const [existing] = await db.select().from(followsTable).where(
    and(eq(followsTable.followerId, viewer.id), eq(followsTable.followingId, target.id)),
  );
  if (existing) {
    await db.delete(followsTable).where(
      and(eq(followsTable.followerId, viewer.id), eq(followsTable.followingId, target.id)),
    );
  } else {
    const inserted = await db.insert(followsTable).values({ followerId: viewer.id, followingId: target.id }).returning();
    if (inserted.length) {
      try {
        await recordNotification({ recipientId: target.userId, actorId: req.userId!, type: "follow", entityType: "profile", entityId: target.id });
      } catch (error) {
        req.log.error({ err: error }, "notification_write_failed");
      }
    }
  }
  const following = await db.select().from(followsTable).where(eq(followsTable.followingId, target.id));
  res.json({ active: !existing, count: following.length });
});

export default router;