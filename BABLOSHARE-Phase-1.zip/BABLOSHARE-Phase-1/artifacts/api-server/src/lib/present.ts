import { and, count, eq } from "drizzle-orm";
import { db, followsTable, profilesTable, videoCommentsTable, videoLikesTable, videosTable } from "@workspace/db";

export async function profileDto(profile: typeof profilesTable.$inferSelect, viewerId?: string) {
  const [followers, following, viewerProfile] = await Promise.all([
    db.select({ count: count() }).from(followsTable).where(eq(followsTable.followingId, profile.id)),
    db.select({ count: count() }).from(followsTable).where(eq(followsTable.followerId, profile.id)),
    viewerId ? db.select({ id: profilesTable.id }).from(profilesTable).where(eq(profilesTable.userId, viewerId)) : Promise.resolve([]),
  ]);
  const viewerProfileId = viewerProfile[0]?.id;
  const follow = viewerProfileId && viewerProfileId !== profile.id
    ? await db.select({ followerId: followsTable.followerId }).from(followsTable).where(and(eq(followsTable.followerId, viewerProfileId), eq(followsTable.followingId, profile.id)))
    : [];

  return {
    id: profile.id,
    userId: profile.userId,
    username: profile.username,
    displayName: profile.displayName,
    bio: profile.bio,
    avatarUrl: profile.avatarUrl,
    coverUrl: profile.coverUrl,
    isVerified: profile.isVerified,
    isCreator: profile.isCreator,
    followerCount: followers[0]?.count ?? 0,
    followingCount: following[0]?.count ?? 0,
    isFollowing: follow.length > 0,
  };
}

export async function creatorDto(profile: typeof profilesTable.$inferSelect) {
  return {
    id: profile.id,
    username: profile.username,
    displayName: profile.displayName,
    avatarUrl: profile.avatarUrl,
    isVerified: profile.isVerified,
    isCreator: profile.isCreator,
  };
}

export async function videoDto(video: typeof videosTable.$inferSelect, viewerId?: string) {
  const [creator, likes, comments, viewerLike] = await Promise.all([
    db.select().from(profilesTable).where(eq(profilesTable.id, video.creatorId)),
    db.select({ count: count() }).from(videoLikesTable).where(eq(videoLikesTable.videoId, video.id)),
    db.select({ count: count() }).from(videoCommentsTable).where(eq(videoCommentsTable.videoId, video.id)),
    viewerId ? db.select({ userId: videoLikesTable.userId }).from(videoLikesTable).where(and(eq(videoLikesTable.videoId, video.id), eq(videoLikesTable.userId, viewerId))) : Promise.resolve([]),
  ]);

  return {
    id: video.id,
    creatorId: video.creatorId,
    title: video.title,
    description: video.description,
    videoType: video.videoType,
    playbackUrl: video.playbackUrl,
    thumbnailUrl: video.thumbnailUrl,
    viewsCount: video.viewsCount,
    createdAt: video.createdAt,
    creator: await creatorDto(creator[0]!),
    likeCount: likes[0]?.count ?? 0,
    commentCount: comments[0]?.count ?? 0,
    isLiked: viewerLike.length > 0,
  };
}