import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const jwtSecret = process.env.SESSION_SECRET ?? "";

if (!jwtSecret) {
  throw new Error("SESSION_SECRET must be set for authentication");
}

declare global {
  namespace Express {
    interface Request {
      userId?: string;
    }
  }
}

export function signUserToken(userId: string): string {
  return jwt.sign({ sub: userId }, jwtSecret, { expiresIn: "7d" });
}

export async function optionalAuth(req: Request, _res: Response, next: NextFunction): Promise<void> {
  const header = req.header("authorization");
  if (header?.startsWith("Bearer ")) {
    let userId: string | undefined;
    try {
      const payload = jwt.verify(header.slice(7), jwtSecret) as jwt.JwtPayload;
      if (typeof payload.sub === "string") userId = payload.sub;
    } catch {
      req.userId = undefined;
    }
    if (userId) {
      const [user] = await db.select({ accountStatus: usersTable.accountStatus }).from(usersTable).where(eq(usersTable.id, userId));
      if (user?.accountStatus === "active") req.userId = userId;
    }
  }
  next();
}

export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const header = req.header("authorization");
  if (!header?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  let userId: string;
  try {
    const payload = jwt.verify(header.slice(7), jwtSecret) as jwt.JwtPayload;
    if (typeof payload.sub !== "string") throw new Error("Invalid subject");
    userId = payload.sub;
  } catch {
    res.status(401).json({ error: "Invalid or expired session" });
    return;
  }
  const [user] = await db.select({ accountStatus: usersTable.accountStatus }).from(usersTable).where(eq(usersTable.id, userId));
  if (!user) { res.status(401).json({ error: "Session user not found" }); return; }
  if (user.accountStatus !== "active") { res.status(403).json({ error: "Account access is suspended" }); return; }
  req.userId = userId;
  next();
}