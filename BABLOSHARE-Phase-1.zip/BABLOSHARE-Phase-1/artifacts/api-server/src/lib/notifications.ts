import { db, notificationsTable } from "@workspace/db";

export async function recordNotification(input: {
  recipientId: string;
  actorId: string;
  type: "follow" | "post_like" | "post_comment" | "video_like" | "video_comment";
  entityType: "profile" | "post" | "video";
  entityId: string;
}) {
  if (input.recipientId === input.actorId) return;
  await db.insert(notificationsTable).values(input);
}
