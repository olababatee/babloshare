import { ObjectStorageService } from "./objectStorage";

const storage = new ObjectStorageService();
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export class MediaValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "MediaValidationError";
  }
}

export async function validateStoredMedia(
  mediaUrl: string,
  userId: string,
  expectedKind?: "image" | "video",
  allowExternal = true,
): Promise<void> {
  const parsed = parseStoredMediaUrl(mediaUrl);
  if (!parsed) {
    if (mediaUrl.startsWith("/api/storage/")) throw new MediaValidationError("The media upload link is invalid.");
    if (allowExternal && /^https?:\/\//i.test(mediaUrl)) return;
    throw new MediaValidationError("Choose a photo or video from your device.");
  }
  if (parsed.ownerId.toLowerCase() !== userId.toLowerCase()) {
    throw new MediaValidationError("You can only attach media uploaded from your account.");
  }

  let customMetadata: Record<string, string>;
  try {
    const file = await storage.getObjectEntityFile(parsed.objectPath);
    const [metadata] = await file.getMetadata();
    customMetadata = (metadata.metadata ?? {}) as Record<string, string>;
  } catch {
    throw new MediaValidationError("The uploaded file was not found. Upload it again.");
  }
  if (
    customMetadata.babloshareValidated !== "true" ||
    customMetadata.babloshareOwner?.toLowerCase() !== userId.toLowerCase()
  ) {
    throw new MediaValidationError("Upload the file again before attaching it.");
  }
  if (expectedKind && customMetadata.babloshareMediaType !== expectedKind) {
    throw new MediaValidationError(expectedKind === "image" ? "Choose an image file." : "Choose a video file.");
  }
}

export function parseStoredMediaUrl(mediaUrl: string): { objectPath: string; ownerId: string } | null {
  if (!mediaUrl.startsWith("/api/storage/object-url?")) return null;
  try {
    const parsedUrl = new URL(mediaUrl, "https://babloshare.invalid");
    if (parsedUrl.pathname !== "/api/storage/object-url") return null;
    const path = parsedUrl.searchParams.get("path") || "";
    const match = /^uploads\/([0-9a-f-]{36})\/([0-9a-f-]{36})$/i.exec(path);
    if (!match || !uuidPattern.test(match[1]) || !uuidPattern.test(match[2])) return null;
    return { objectPath: `/objects/${path}`, ownerId: match[1] };
  } catch {
    return null;
  }
}
