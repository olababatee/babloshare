import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { WebhookHandlers } from "./webhookHandlers";
import { handleVerifiedStripeEvent } from "./economyService";
import Stripe from "stripe";

const app: Express = express();

app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  const signature = req.headers["stripe-signature"];
  if (!signature) {
    res.status(400).json({ error: "Missing stripe-signature" });
    return;
  }
  try {
    const payload = req.body as Buffer;
    await WebhookHandlers.processWebhook(payload, Array.isArray(signature) ? signature[0] : signature);
    const event = JSON.parse(payload.toString("utf8")) as Stripe.Event;
    await handleVerifiedStripeEvent(event);
    res.status(200).json({ received: true });
  } catch (error) {
    logger.error({ err: error }, "Stripe webhook processing failed");
    res.status(400).json({ error: "Webhook processing error" });
  }
});

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
