import { and, asc, desc, eq, sql } from "drizzle-orm";
import Stripe from "stripe";
import {
  creatorOffersTable,
  creatorSubscriptionsTable,
  db,
  ledgerEntriesTable,
  walletsTable,
} from "@workspace/db";
import { getUncachableStripeClient } from "./stripeClient";

export async function ensureWallet(userId: string) {
  await db.insert(walletsTable).values({ userId }).onConflictDoNothing({ target: walletsTable.userId });
  const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.userId, userId));
  if (!wallet) throw new Error("Wallet could not be created.");
  return wallet;
}

export async function recordLedgerEntry(input: {
  creatorId: string;
  entryType: "tip" | "subscription" | "payout" | "adjustment";
  status: "pending" | "available" | "paid" | "reversed";
  amount: number;
  idempotencyKey: string;
  description: string;
  stripePaymentIntentId?: string | null;
  stripeCheckoutSessionId?: string | null;
  stripeSubscriptionId?: string | null;
  metadata?: Record<string, string>;
}) {
  const wallet = await ensureWallet(input.creatorId);
  const inserted = await db.insert(ledgerEntriesTable).values({
    walletId: wallet.id,
    entryType: input.entryType,
    status: input.status,
    amount: input.amount,
    currency: "usd",
    idempotencyKey: input.idempotencyKey,
    description: input.description,
    stripePaymentIntentId: input.stripePaymentIntentId ?? null,
    stripeCheckoutSessionId: input.stripeCheckoutSessionId ?? null,
    stripeSubscriptionId: input.stripeSubscriptionId ?? null,
    metadata: input.metadata ?? {},
  }).onConflictDoNothing({ target: ledgerEntriesTable.idempotencyKey }).returning();
  return inserted[0] ?? (await db.select().from(ledgerEntriesTable).where(eq(ledgerEntriesTable.idempotencyKey, input.idempotencyKey)))[0];
}

export async function verifyAndRecordCheckout(sessionId: string, expectedUserId: string) {
  const stripe = await getUncachableStripeClient();
  const session = await stripe.checkout.sessions.retrieve(sessionId);
  if (session.metadata?.subscriber_user_id !== expectedUserId) {
    return { status: "rejected" as const, amountMinor: 0, currency: "usd" as const, ledgerEntryId: null };
  }
  const amount = session.amount_total ?? 0;
  const creatorId = session.metadata?.creator_user_id;
  if (session.payment_status !== "paid" || !creatorId || amount <= 0) {
    return { status: "pending" as const, amountMinor: amount, currency: "usd" as const, ledgerEntryId: null };
  }
  const type = session.metadata?.economy_type === "subscription" ? "subscription" : "tip";
  const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;
  if (type === "subscription") {
    const stripe = await getUncachableStripeClient();
    const subscription = await stripe.subscriptions.retrieve(subscriptionId!);
    await upsertCreatorSubscription(expectedUserId, creatorId, subscription);
    return { status: "verified" as const, amountMinor: amount, currency: "usd" as const, ledgerEntryId: null };
  }
  const entry = await recordLedgerEntry({
    creatorId,
    entryType: type,
    status: "available",
    amount,
    idempotencyKey: `checkout:${session.id}`,
    description: type === "tip" ? "Fan tip" : "Creator subscription",
    stripePaymentIntentId: typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id,
    stripeCheckoutSessionId: session.id,
    stripeSubscriptionId: subscriptionId,
    metadata: {
      subscriberUserId: expectedUserId,
      creatorUserId: creatorId,
      ...(session.metadata?.message ? { message: session.metadata.message } : {}),
    },
  });
  return { status: "verified" as const, amountMinor: amount, currency: "usd" as const, ledgerEntryId: entry?.id ?? null };
}

export async function recordPaidInvoice(invoice: Stripe.Invoice) {
  const invoiceSubscription = (invoice as unknown as { subscription?: string | Stripe.Subscription }).subscription;
  const subscriptionId = typeof invoiceSubscription === "string" ? invoiceSubscription : invoiceSubscription?.id;
  if (!subscriptionId) return;
  const stripe = await getUncachableStripeClient();
  const subscription = await stripe.subscriptions.retrieve(subscriptionId);
  const creatorId = subscription.metadata?.creator_user_id;
  const subscriberId = subscription.metadata?.subscriber_user_id;
  if (!creatorId || !subscriberId || invoice.amount_paid <= 0) return;
  await recordLedgerEntry({
    creatorId,
    entryType: "subscription",
    status: "available",
    amount: invoice.amount_paid,
    idempotencyKey: `invoice:${invoice.id}`,
    description: "Creator subscription renewal",
    stripeSubscriptionId: subscriptionId,
    metadata: { subscriberUserId: subscriberId, creatorUserId: creatorId },
  });
  await upsertCreatorSubscription(subscriberId, creatorId, subscription);
}

export async function handleVerifiedStripeEvent(event: Stripe.Event) {
  if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
    const session = event.data.object as Stripe.Checkout.Session;
    const creatorId = session.metadata?.creator_user_id;
    const subscriberId = session.metadata?.subscriber_user_id;
    if (session.payment_status !== "paid" || !creatorId || !subscriberId || !session.amount_total) return;
    const type = session.metadata?.economy_type === "subscription" ? "subscription" : "tip";
    const subscriptionId = typeof session.subscription === "string" ? session.subscription : session.subscription?.id;
    if (type === "subscription") {
      if (subscriptionId) {
        const stripe = await getUncachableStripeClient();
        await upsertCreatorSubscription(subscriberId, creatorId, await stripe.subscriptions.retrieve(subscriptionId));
      }
      return;
    }
    await recordLedgerEntry({
      creatorId,
      entryType: type,
      status: "available",
      amount: session.amount_total,
      idempotencyKey: `checkout:${session.id}`,
      description: type === "tip" ? "Fan tip" : "Creator subscription",
      stripePaymentIntentId: typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id,
      stripeCheckoutSessionId: session.id,
      stripeSubscriptionId: subscriptionId,
      metadata: { subscriberUserId: subscriberId, creatorUserId: creatorId },
    });
    return;
  }
  if (event.type === "invoice.paid") {
    await recordPaidInvoice(event.data.object as Stripe.Invoice);
    return;
  }
  if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
    const subscription = event.data.object as Stripe.Subscription;
    const subscriberId = subscription.metadata?.subscriber_user_id;
    const creatorId = subscription.metadata?.creator_user_id;
    if (subscriberId && creatorId) await upsertCreatorSubscription(subscriberId, creatorId, subscription);
    return;
  }
  if (event.type === "refund.created") {
    const refund = event.data.object as Stripe.Refund;
    const paymentIntentId = typeof refund.payment_intent === "string" ? refund.payment_intent : refund.payment_intent?.id;
    if (!paymentIntentId || refund.amount <= 0) return;
    const [original] = await db.select().from(ledgerEntriesTable).where(eq(ledgerEntriesTable.stripePaymentIntentId, paymentIntentId)).orderBy(asc(ledgerEntriesTable.createdAt)).limit(1);
    if (!original) return;
    const [wallet] = await db.select().from(walletsTable).where(eq(walletsTable.id, original.walletId));
    if (!wallet) return;
    await recordLedgerEntry({
      creatorId: wallet.userId,
      entryType: original.entryType,
      status: "available",
      amount: -refund.amount,
      idempotencyKey: `refund:${refund.id}`,
      description: "Payment refund",
      stripePaymentIntentId: paymentIntentId,
      stripeCheckoutSessionId: original.stripeCheckoutSessionId,
      metadata: original.metadata,
    });
  }
}

export async function upsertCreatorSubscription(subscriberId: string, creatorId: string, subscription: Stripe.Subscription) {
  await db.insert(creatorSubscriptionsTable).values({
    subscriberId,
    creatorId,
    stripeSubscriptionId: subscription.id,
    status: subscription.status,
    currentPeriodEnd: new Date(subscription.items.data[0]?.current_period_end ? subscription.items.data[0].current_period_end * 1000 : Date.now()),
  }).onConflictDoUpdate({
    target: creatorSubscriptionsTable.stripeSubscriptionId,
    set: {
      status: subscription.status,
      currentPeriodEnd: new Date(subscription.items.data[0]?.current_period_end ? subscription.items.data[0].current_period_end * 1000 : Date.now()),
      updatedAt: new Date(),
    },
  });
}

export async function getOfferForCreator(creatorId: string) {
  const [offer] = await db.select().from(creatorOffersTable).where(and(eq(creatorOffersTable.creatorId, creatorId), eq(creatorOffersTable.active, 1)));
  if (!offer) return null;
  const stripe = await getUncachableStripeClient();
  const [product, price] = await Promise.all([
    stripe.products.retrieve(offer.stripeProductId),
    stripe.prices.retrieve(offer.stripePriceId),
  ]);
  if (product.deleted || !price.active || !price.unit_amount) return null;
  return {
    creatorUsername: "",
    name: product.name,
    description: product.description ?? "",
    priceId: price.id,
    amountMinor: price.unit_amount,
    currency: "usd" as const,
    interval: price.recurring?.interval === "year" ? "year" as const : "month" as const,
    active: true,
  };
}