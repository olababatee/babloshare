import { useEffect, useId, useState } from "react";
import { LoaderCircle, UploadCloud } from "lucide-react";

export type UploadedMedia = {
  mediaUrl: string;
  mediaType: "image" | "video";
  contentType: string;
  size: number;
};

type Props = {
  label: string;
  accept?: string;
  maxBytes?: number;
  onUploaded: (media: UploadedMedia) => void;
  disabled?: boolean;
};

const defaultMaxBytes = 120 * 1024 * 1024;

async function uploadFromDevice(file: File, onProgress: (value: number) => void): Promise<UploadedMedia> {
  const token = localStorage.getItem("babloshare-token");
  if (!token) throw new Error("Sign in before uploading media.");

  const request = await fetch("/api/storage/uploads/request-url", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
  });
  const requestBody = await request.json().catch(() => ({})) as { uploadURL?: string; objectPath?: string; error?: string };
  if (!request.ok || !requestBody.uploadURL || !requestBody.objectPath) {
    throw new Error(requestBody.error || "Could not prepare this upload.");
  }

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", requestBody.uploadURL!);
    xhr.setRequestHeader("Content-Type", file.type);
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) onProgress(Math.round((event.loaded / event.total) * 100));
    };
    xhr.onerror = () => reject(new Error("Upload failed. Check your connection and try again."));
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve();
      else reject(new Error(`Upload failed (${xhr.status}). Try again.`));
    };
    xhr.send(file);
  });

  const complete = await fetch("/api/storage/uploads/complete", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ objectPath: requestBody.objectPath }),
  });
  const result = await complete.json().catch(() => ({})) as UploadedMedia & { error?: string };
  if (!complete.ok || !result.mediaUrl || !result.mediaType) {
    throw new Error(result.error || "The uploaded file could not be verified.");
  }
  return result;
}

export function MediaGalleryPicker({ label, accept = "image/jpeg,image/png,image/webp,image/gif", maxBytes = defaultMaxBytes, onUploaded, disabled }: Props) {
  const inputId = useId();
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [fileName, setFileName] = useState("");
  const [error, setError] = useState("");
  const [preview, setPreview] = useState("");
  const [previewType, setPreviewType] = useState<"image" | "video">("image");

  useEffect(() => () => {
    if (preview) URL.revokeObjectURL(preview);
  }, [preview]);

  const selectFile = async (file?: File) => {
    if (!file) return;
    setError("");
    setFileName(file.name);
    if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
      setError("Choose an image or video file from your gallery.");
      return;
    }
    const typeLimit = file.type.startsWith("image/") ? 15 * 1024 * 1024 : defaultMaxBytes;
    const actualLimit = Math.min(maxBytes, typeLimit);
    if (file.size > actualLimit) {
      setError(`This file is too large. The limit is ${Math.round(actualLimit / (1024 * 1024))} MB.`);
      return;
    }
    if (preview) URL.revokeObjectURL(preview);
    setPreviewType(file.type.startsWith("video/") ? "video" : "image");
    setPreview(URL.createObjectURL(file));
    setBusy(true);
    setProgress(0);
    try {
      const uploaded = await uploadFromDevice(file, setProgress);
      onUploaded(uploaded);
      setProgress(100);
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : "Upload failed. Try again.");
    } finally {
      setBusy(false);
    }
  };

  return <div className="space-y-2">
    <span className="block text-xs font-bold">{label}</span>
    <label htmlFor={inputId} className={`inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-border bg-card px-4 py-2 text-sm font-bold text-foreground hover:bg-muted ${disabled || busy ? "pointer-events-none opacity-60" : ""}`}>
      {busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4 text-primary" />}
      {busy ? `Uploading${progress ? ` ${progress}%` : "…"}` : "Choose from gallery"}
    </label>
    <input
      id={inputId}
      className="sr-only"
      type="file"
      accept={accept}
      disabled={disabled || busy}
      aria-label={label}
      onChange={(event) => {
        void selectFile(event.currentTarget.files?.[0]);
        event.currentTarget.value = "";
      }}
    />
    {fileName && <p className="truncate text-xs text-muted-foreground">{fileName}</p>}
    {preview && <div className="max-h-48 max-w-full overflow-hidden rounded-xl border border-border bg-muted">
      {previewType === "video"
        ? <video src={preview} controls playsInline className="max-h-48 w-full object-contain" />
        : <img src={preview} alt={`Preview for ${label}`} className="max-h-48 w-full object-contain" />}
    </div>}
    {error && <p role="alert" className="text-xs font-medium text-destructive">{error}</p>}
  </div>;
}
