import { useQuery } from "@tanstack/react-query";
import type { ImgHTMLAttributes, VideoHTMLAttributes } from "react";

function useResolvedMediaUrl(source?: string | null) {
  const query = useQuery({
    queryKey: ["babloshare-media-url", source],
    enabled: Boolean(source?.startsWith("/api/storage/object-url?")),
    staleTime: 45 * 60 * 1000,
    retry: false,
    queryFn: async () => {
      const token = localStorage.getItem("babloshare-token");
      const response = await fetch(source!, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      const body = await response.json().catch(() => ({})) as { url?: string; error?: string };
      if (!response.ok || !body.url) throw new Error(body.error || "Media is unavailable.");
      return body.url;
    },
  });

  if (!source) return undefined;
  if (!source.startsWith("/api/storage/object-url?")) return source;
  return query.data;
}

export function MediaImage({
  src,
  alt,
  className,
  ...props
}: ImgHTMLAttributes<HTMLImageElement>) {
  const resolved = useResolvedMediaUrl(src);
  return resolved
    ? <img src={resolved} alt={alt || ""} className={className} {...props} />
    : <span role="img" aria-label={alt || "Image loading"} className={`block animate-pulse bg-muted ${className || ""}`} />;
}

export function MediaVideo({
  src,
  poster,
  className,
  ...props
}: VideoHTMLAttributes<HTMLVideoElement>) {
  const resolved = useResolvedMediaUrl(src);
  const resolvedPoster = useResolvedMediaUrl(poster);
  return resolved
    ? <video src={resolved} poster={resolvedPoster} className={className} playsInline {...props} />
    : <div role="status" aria-label="Video loading" className={`animate-pulse bg-muted ${className || ""}`} />;
}
