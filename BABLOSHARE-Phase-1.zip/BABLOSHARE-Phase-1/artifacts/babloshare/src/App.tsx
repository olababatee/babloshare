import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import {
  ArrowRight, Bell, Bookmark, Check, ChevronRight, Compass, Disc3, Eye, Heart, Home,
  FileText, LoaderCircle, LogIn, Menu, MessageCircle, MoreHorizontal, Play, Plus, Search,
  Send, Share2, ShieldCheck, Sparkles, UserRound, Users, Video as VideoIcon, X, Zap,
} from 'lucide-react';
import {
  getGetCurrentUserQueryKey, getGetProfileQueryKey, getListProfileVideosQueryKey, getListPostsQueryKey, getListPostCommentsQueryKey,
  getListVideoCommentsQueryKey, getListVideosQueryKey, getSearchQueryKey, setAuthTokenGetter,
  useCreatePost, useCreatePostComment, useCreateVideo, useCreateVideoComment, useDeletePost, useGetCurrentUser, useGetProfile, useListPostComments, useListPosts, useListProfileVideos,
  useListVideoComments, useListVideos, useLogin, useRegister, useSearch, useToggleFollow,
  useTogglePostLike, useToggleVideoLike, useUpdatePost, useUpdateMyProfile,
  getGetCreatorOfferQueryKey, useGetCreatorOffer, useCreateTipCheckout,
  useCreateSubscriptionCheckout, useConfirmEconomyCheckout,
  useRecordVideoView,
  getGetNotificationsQueryKey, useGetNotifications, useMarkNotificationsRead,
  getListAdminReportsQueryKey, useListAdminReports, useReviewAdminReport,
  getListAdminUsersQueryKey, useListAdminUsers, useUpdateAdminUserStatus,
} from '@workspace/api-client-react';
import type { AdminReport, AdminUser, Comment, FeedPost, Notification, PostComment, Profile, Video } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { MediaImage, MediaVideo } from '@/components/MediaDisplay';
import { MediaGalleryPicker, type UploadedMedia } from '@/components/MediaGalleryPicker';
import NotFound from '@/pages/not-found';
import { CommunityPage, GroupPage, InboxPage, PageProfile, PagesPage, StoriesPage } from '@/pages/Phase2';
import CreatorStudio from '@/pages/CreatorStudio';

const queryClient = new QueryClient();

function initials(name?: string | null) {
  return (name || 'B').split(' ').slice(0, 2).map((part) => part[0]).join('').toUpperCase();
}

function formatCount(value: number) {
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}m`;
  if (value >= 1000) return `${(value / 1000).toFixed(value >= 10000 ? 0 : 1)}k`;
  return String(value);
}

function timeAgo(value: string) {
  const seconds = Math.max(1, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  return `${Math.floor(seconds / 86400)}d`;
}

function Avatar({ profile, size = 'md' }: { profile?: { displayName?: string; avatarUrl?: string | null } | null; size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'h-8 w-8 text-[10px]', md: 'h-10 w-10 text-xs', lg: 'h-20 w-20 text-xl' };
  return profile?.avatarUrl ? (
    <MediaImage data-testid="img-avatar" src={profile.avatarUrl} alt={profile.displayName || 'Profile'} className={`${sizes[size]} shrink-0 rounded-full object-cover ring-2 ring-background`} />
  ) : (
    <div data-testid="avatar-fallback" className={`${sizes[size]} shrink-0 rounded-full bg-[#f1a27e] text-[#2b2345] ring-2 ring-background flex items-center justify-center font-display font-bold`}>
      {initials(profile?.displayName)}
    </div>
  );
}

function Verified() {
  return <span data-testid="badge-verified" className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-primary text-primary-foreground"><Check className="h-2.5 w-2.5" strokeWidth={3} /></span>;
}

function Logo({ inverted = false }: { inverted?: boolean }) {
  return <Link href="/" data-testid="link-logo" className={`flex items-center gap-2.5 ${inverted ? 'text-[#f8f1e6]' : 'text-foreground'}`}>
    <span className="relative flex h-9 w-9 items-center justify-center rounded-[13px] bg-primary text-primary-foreground shadow-[4px_4px_0_0_#f1a27e]">
      <span className="font-display text-lg font-bold">B</span>
      <span className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full bg-accent" />
    </span>
    <span className="font-display text-xl font-bold tracking-[-.06em]">BABLO<span className="text-primary">SHARE</span></span>
  </Link>;
}

function Status({ kind, title, body, retry }: { kind: 'loading' | 'error' | 'empty'; title: string; body: string; retry?: () => void }) {
  if (kind === 'loading') return <div className="space-y-4 py-8" data-testid="status-loading"><div className="h-40 animate-pulse rounded-3xl bg-muted" /><div className="h-5 w-2/3 animate-pulse rounded bg-muted" /><div className="h-4 w-1/3 animate-pulse rounded bg-muted" /></div>;
  return <div data-testid={`status-${kind}`} className="flex min-h-56 flex-col items-center justify-center rounded-[28px] border border-dashed border-border bg-card/60 p-8 text-center">
    <div className={`mb-4 flex h-12 w-12 items-center justify-center rounded-2xl ${kind === 'error' ? 'bg-[#f9d9ce] text-destructive' : 'bg-secondary text-primary'}`}>
      {kind === 'error' ? <X className="h-5 w-5" /> : <Sparkles className="h-5 w-5" />}
    </div>
    <h3 className="font-display text-lg font-bold">{title}</h3>
    <p className="mt-1 max-w-xs text-sm leading-6 text-muted-foreground">{body}</p>
    {retry && <button data-testid="button-retry" onClick={retry} className="mt-5 text-sm font-bold text-primary underline underline-offset-4">Try again</button>}
  </div>;
}

function NavItem({ href, label, icon: Icon, active, badge }: { href: string; label: string; icon: typeof Home; active: boolean; badge?: number }) {
  return <Link href={href} data-testid={`link-nav-${label.toLowerCase()}`} className={`group flex items-center gap-3 rounded-2xl px-3.5 py-3 text-sm font-semibold transition-all ${active ? 'bg-primary text-primary-foreground shadow-[3px_3px_0_0_#f1a27e]' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
    <Icon className="h-[18px] w-[18px]" strokeWidth={active ? 2.4 : 1.8} /><span>{label}</span>{Boolean(badge) && <span className="ml-auto rounded-full bg-accent px-2 py-0.5 font-mono-ui text-[10px] font-bold text-white">{badge! > 99 ? '99+' : badge}</span>}
  </Link>;
}

function AppShell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const client = useQueryClient();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const current = useGetCurrentUser({ query: { enabled: Boolean(localStorage.getItem('babloshare-token')), queryKey: getGetCurrentUserQueryKey() } });
  const notifications = useGetNotifications({ query: { enabled: Boolean(localStorage.getItem('babloshare-token')), queryKey: getGetNotificationsQueryKey(), refetchInterval: 60_000 } });
  const profile = current.data?.profile;
  const logout = () => {
    localStorage.removeItem('babloshare-token');
    client.clear();
    setMobileMenuOpen(false);
    setLocation('/');
  };
  return <div className="grain min-h-[100dvh] bg-background">
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-[250px] flex-col border-r border-border bg-[#f6f0e5] px-6 py-7 lg:flex">
      <Logo />
      <div className="mt-14 space-y-1">
        <p className="mb-4 px-3.5 font-mono-ui text-[10px] uppercase tracking-[.2em] text-muted-foreground">The everyday loop</p>
        <NavItem href="/explore" label="Explore" icon={Compass} active={location === '/explore'} />
        <NavItem href="/feed" label="Posts" icon={FileText} active={location === '/feed'} />
        <NavItem href="/watch" label="Watch" icon={Play} active={location === '/watch'} />
        <NavItem href="/search" label="Find people" icon={Search} active={location === '/search'} />
        <NavItem href="/community" label="Communities" icon={Users} active={location.startsWith('/community') || location.startsWith('/groups')} />
        <NavItem href="/pages" label="Pages" icon={Sparkles} active={location.startsWith('/pages')} />
        <NavItem href="/stories" label="Stories" icon={Eye} active={location === '/stories'} />
        <NavItem href="/inbox" label="Inbox" icon={MessageCircle} active={location === '/inbox'} />
        {profile && <NavItem href="/notifications" label="Notifications" icon={Bell} active={location === '/notifications'} badge={notifications.data?.unreadCount} />}
        {current.data?.role === 'admin' && <NavItem href="/admin" label="Administration" icon={ShieldCheck} active={location === '/admin'} />}
        {profile?.isCreator && <NavItem href="/studio" label="Creator Studio" icon={Sparkles} active={location === '/studio'} />}
        {profile && <NavItem href={`/profile/${profile.username}`} label="Your profile" icon={UserRound} active={location.startsWith('/profile')} />}
      </div>
      <div className="mt-auto">
        <button data-testid="button-open-composer-sidebar" onClick={() => setComposerOpen(true)} className="mb-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-accent px-4 py-3.5 text-sm font-extrabold text-white shadow-[4px_4px_0_0_#2b2345] transition-transform hover:-translate-y-0.5 active:translate-y-0"><Plus className="h-4 w-4" /> Share a thought</button>
        {profile ? <Link href={`/profile/${profile.username}`} data-testid="link-sidebar-profile" className="flex items-center gap-3 rounded-2xl border border-border bg-card/50 p-3">
          <Avatar profile={profile} size="sm" /><div className="min-w-0"><p className="truncate text-sm font-bold">{profile.displayName}</p><p className="truncate font-mono-ui text-[10px] text-muted-foreground">@{profile.username}</p></div><MoreHorizontal className="ml-auto h-4 w-4 text-muted-foreground" />
        </Link> : <Link href="/login" data-testid="link-sidebar-login" className="flex items-center gap-2 rounded-2xl border border-border p-3 text-sm font-bold"><LogIn className="h-4 w-4" /> Sign in</Link>}
        {profile && <button onClick={logout} className="mt-2 w-full rounded-xl px-3 py-2 text-left text-xs font-bold text-muted-foreground hover:bg-muted hover:text-destructive">Sign out</button>}
      </div>
    </aside>
    <header className="sticky top-0 z-20 flex items-center justify-between border-b border-border/70 bg-background/90 px-4 py-4 backdrop-blur-lg lg:hidden">
      <Logo />
      <div className="flex items-center gap-2">{profile ? <><Link href={`/profile/${profile.username}`} data-testid="link-mobile-profile"><Avatar profile={profile} size="sm" /></Link><Link href="/notifications" aria-label={`Notifications${notifications.data?.unreadCount ? `, ${notifications.data.unreadCount} unread` : ''}`} className="relative rounded-xl p-2 text-muted-foreground"><Bell className="h-5 w-5" />{Boolean(notifications.data?.unreadCount) && <span className="absolute -right-0.5 -top-0.5 min-w-4 rounded-full bg-accent px-1 text-center font-mono-ui text-[9px] font-bold text-white">{notifications.data!.unreadCount > 99 ? '99+' : notifications.data!.unreadCount}</span>}</Link></> : <Link href="/login" data-testid="link-mobile-login" className="rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground">Sign in</Link>}<button aria-label="Open navigation menu" aria-expanded={mobileMenuOpen} onClick={() => setMobileMenuOpen(!mobileMenuOpen)} data-testid="button-mobile-menu" className="rounded-xl p-2 text-muted-foreground"><Menu className="h-5 w-5" /></button></div>
    </header>
    {mobileMenuOpen && <div className="sticky top-[65px] z-20 grid grid-cols-2 gap-2 border-b border-border bg-card p-4 shadow-lg lg:hidden">
      <Link onClick={() => setMobileMenuOpen(false)} href="/search" className="rounded-xl bg-muted p-3 text-sm font-bold">Find people</Link>
      <Link onClick={() => setMobileMenuOpen(false)} href="/community" className="rounded-xl bg-muted p-3 text-sm font-bold">Communities</Link>
      <Link onClick={() => setMobileMenuOpen(false)} href="/pages" className="rounded-xl bg-muted p-3 text-sm font-bold">Pages</Link>
      <Link onClick={() => setMobileMenuOpen(false)} href="/stories" className="rounded-xl bg-muted p-3 text-sm font-bold">Stories</Link>
      <Link onClick={() => setMobileMenuOpen(false)} href="/inbox" className="rounded-xl bg-muted p-3 text-sm font-bold">Inbox</Link>
      {profile && <Link onClick={() => setMobileMenuOpen(false)} href="/notifications" className="flex items-center justify-between rounded-xl bg-muted p-3 text-sm font-bold">Notifications{Boolean(notifications.data?.unreadCount) && <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] text-white">{notifications.data!.unreadCount}</span>}</Link>}
      {current.data?.role === 'admin' && <Link onClick={() => setMobileMenuOpen(false)} href="/admin" className="rounded-xl bg-muted p-3 text-sm font-bold">Administration</Link>}
      {profile?.isCreator && <Link onClick={() => setMobileMenuOpen(false)} href="/studio" className="rounded-xl bg-muted p-3 text-sm font-bold">Creator Studio</Link>}
      {profile && <button onClick={logout} className="rounded-xl border border-border p-3 text-left text-sm font-bold text-destructive">Sign out</button>}
    </div>}
    <main className="pb-24 lg:pl-[250px] lg:pb-0">{children}</main>
    <nav className="fixed inset-x-0 bottom-0 z-30 flex h-[74px] items-center justify-around border-t border-border bg-[#f6f0e5]/95 px-5 backdrop-blur-lg lg:hidden">
      <Link href="/explore" data-testid="link-bottom-explore" className={`flex flex-col items-center gap-1 text-[10px] font-bold ${location === '/explore' ? 'text-primary' : 'text-muted-foreground'}`}><Compass className="h-5 w-5" />Explore</Link>
      <Link href="/watch" data-testid="link-bottom-watch" className={`flex flex-col items-center gap-1 text-[10px] font-bold ${location === '/watch' ? 'text-primary' : 'text-muted-foreground'}`}><Play className="h-5 w-5" />Watch</Link>
      <button data-testid="button-open-composer-mobile" onClick={() => setComposerOpen(true)} className="flex h-12 w-12 -translate-y-3 items-center justify-center rounded-2xl bg-accent text-white shadow-[3px_3px_0_0_#2b2345]"><Plus className="h-6 w-6" /></button>
      <Link href="/feed" data-testid="link-bottom-feed" className={`flex flex-col items-center gap-1 text-[10px] font-bold ${location === '/feed' ? 'text-primary' : 'text-muted-foreground'}`}><FileText className="h-5 w-5" />Posts</Link>
       <Link href="/community" data-testid="link-bottom-community" className={`flex flex-col items-center gap-1 text-[10px] font-bold ${location.startsWith('/community') || location.startsWith('/groups') ? 'text-primary' : 'text-muted-foreground'}`}><Users className="h-5 w-5" />Rooms</Link>
      <Link href={profile ? `/profile/${profile.username}` : '/login'} data-testid="link-bottom-profile" className="flex flex-col items-center gap-1 text-[10px] font-bold text-muted-foreground"><UserRound className="h-5 w-5" />Profile</Link>
    </nav>
    {composerOpen && <Composer onClose={() => setComposerOpen(false)} />}
  </div>;
}

function Composer({ onClose }: { onClose: () => void }) {
  const client = useQueryClient();
  const create = useCreateVideo();
  const [form, setForm] = useState({ title: '', description: '', playbackUrl: '', thumbnailUrl: '', videoType: 'short' as 'short' | 'long' });
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.playbackUrl) return;
    create.mutate({ data: { ...form, thumbnailUrl: form.thumbnailUrl || undefined } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListVideosQueryKey() }); onClose(); } });
  };
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#2b2345]/35 p-0 backdrop-blur-sm sm:items-center sm:p-6">
    <form onSubmit={submit} data-testid="form-create-video" className="appear w-full max-w-lg rounded-t-[30px] border border-border bg-card p-6 shadow-2xl sm:rounded-[30px]">
      <div className="mb-6 flex items-start justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Put it out there</p><h2 className="mt-1 font-display text-2xl font-bold">Share a piece of your world.</h2></div><button type="button" onClick={onClose} data-testid="button-close-composer" className="rounded-xl p-2 text-muted-foreground hover:bg-muted"><X className="h-5 w-5" /></button></div>
      <div className="space-y-3">
        <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} data-testid="input-video-title" placeholder="Give it a title" className="h-12 w-full rounded-2xl border border-input bg-background px-4 text-sm outline-none focus:border-primary" />
        <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} data-testid="input-video-description" placeholder="A little context goes a long way..." className="min-h-20 w-full resize-none rounded-2xl border border-input bg-background px-4 py-3 text-sm outline-none focus:border-primary" />
        <MediaGalleryPicker label="Video file" accept="video/mp4,video/webm,video/quicktime" maxBytes={120 * 1024 * 1024} onUploaded={(media) => setForm({ ...form, playbackUrl: media.mediaUrl })} />
        <MediaGalleryPicker label="Thumbnail (optional)" onUploaded={(media) => setForm({ ...form, thumbnailUrl: media.mediaUrl })} />
        {!form.playbackUrl && <p className="text-xs text-muted-foreground">Choose a video from your phone gallery before publishing.</p>}
        <div className="flex gap-2"><button type="button" onClick={() => setForm({ ...form, videoType: 'short' })} data-testid="button-video-type-short" className={`flex-1 rounded-2xl border px-4 py-3 text-sm font-bold ${form.videoType === 'short' ? 'border-primary bg-secondary text-primary' : 'border-border text-muted-foreground'}`}>Short format</button><button type="button" onClick={() => setForm({ ...form, videoType: 'long' })} data-testid="button-video-type-long" className={`flex-1 rounded-2xl border px-4 py-3 text-sm font-bold ${form.videoType === 'long' ? 'border-primary bg-secondary text-primary' : 'border-border text-muted-foreground'}`}>Long format</button></div>
      </div>
      {create.isError && <p data-testid="status-create-error" role="alert" className="mt-3 text-sm text-destructive">That video could not be published. Check the selected file and try again.</p>}
      <button disabled={create.isPending || !form.playbackUrl} type="submit" data-testid="button-submit-video" className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary font-bold text-primary-foreground disabled:opacity-60">{create.isPending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Publish to BABLOSHARE</button>
    </form>
  </div>;
}

function PostComments({ postId, onChanged }: { postId: string; onChanged: () => void }) {
  const client = useQueryClient();
  const comments = useListPostComments(postId, { query: { queryKey: getListPostCommentsQueryKey(postId) } });
  const create = useCreatePostComment();
  const [content, setContent] = useState('');
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!content.trim()) return;
    create.mutate({ id: postId, data: { content: content.trim() } }, {
      onSuccess: () => {
        setContent('');
        client.invalidateQueries({ queryKey: getListPostCommentsQueryKey(postId) });
        onChanged();
      },
    });
  };
  return <div className="mt-4 rounded-2xl bg-muted/60 p-4">
    {comments.isLoading ? <p className="text-sm text-muted-foreground">Loading comments…</p>
      : comments.isError ? <p role="alert" className="text-sm text-destructive">Comments are unavailable right now.</p>
      : !comments.data?.length ? <p className="mb-3 text-sm text-muted-foreground">No comments yet. Start the conversation.</p>
      : <ul className="mb-3 max-h-56 space-y-3 overflow-auto">{comments.data.map((comment: PostComment) => <li key={comment.id} className="flex gap-2"><Avatar profile={comment.author} size="sm" /><div><p className="text-xs font-bold">{comment.author.displayName}<span className="ml-2 font-mono-ui font-normal text-muted-foreground">{timeAgo(comment.createdAt)}</span></p><p className="mt-1 whitespace-pre-wrap text-sm leading-5">{comment.content}</p></div></li>)}</ul>}
    <form onSubmit={submit} className="flex gap-2"><input aria-label="Write a comment" maxLength={500} value={content} onChange={(event) => setContent(event.target.value)} className="h-10 min-w-0 flex-1 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:border-primary" placeholder="Write a comment…" /><button disabled={create.isPending || !content.trim()} aria-label="Send comment" className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground disabled:opacity-50"><Send className="h-4 w-4" /></button></form>
  </div>;
}

function FeedPostCard({ post, currentProfileId, changed }: { post: FeedPost; currentProfileId?: string; changed: () => void }) {
  const client = useQueryClient();
  const like = useTogglePostLike();
  const update = useUpdatePost();
  const remove = useDeletePost();
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(post.content);
  const mine = currentProfileId === post.author.id;
  const toggleLike = () => like.mutate({ id: post.id }, { onSuccess: changed });
  const save = (event: FormEvent) => {
    event.preventDefault();
    if (!draft.trim()) return;
    update.mutate({ id: post.id, data: { content: draft.trim() } }, { onSuccess: () => { setEditing(false); changed(); } });
  };
  const deleteOwnPost = () => {
    if (!window.confirm("Delete this post? This cannot be undone.")) return;
    remove.mutate({ id: post.id }, { onSuccess: changed });
  };
  return <article data-testid={`card-post-${post.id}`} className="rounded-[26px] border border-border bg-card p-5 sm:p-6">
    <div className="flex items-start gap-3">
      <Link href={`/profile/${post.author.username}`} aria-label={`${post.author.displayName}'s profile`}><Avatar profile={post.author} /></Link>
      <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><Link href={`/profile/${post.author.username}`} className="text-sm font-bold hover:text-primary">{post.author.displayName}</Link>{post.author.isVerified && <Verified />}<span className="font-mono-ui text-[10px] text-muted-foreground">@{post.author.username}</span><span className="ml-auto font-mono-ui text-[10px] text-muted-foreground">{timeAgo(post.createdAt)} ago</span></div>
        {editing ? <form onSubmit={save} className="mt-4"><textarea aria-label="Edit post" maxLength={2000} value={draft} onChange={(event) => setDraft(event.target.value)} className="field min-h-24 resize-y py-3" /><div className="mt-2 flex gap-2"><button disabled={update.isPending || !draft.trim()} className="rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground">{update.isPending ? "Saving…" : "Save"}</button><button type="button" onClick={() => { setDraft(post.content); setEditing(false); }} className="rounded-xl border border-border px-3 py-2 text-xs font-bold">Cancel</button></div></form>
          : <><p className="mt-4 whitespace-pre-wrap break-words text-sm leading-6">{post.content}</p>
            {post.mediaUrl && <div className="mt-4 overflow-hidden rounded-2xl bg-muted">
              {post.mediaType === "video"
                ? <MediaVideo src={post.mediaUrl} controls className="max-h-[560px] w-full object-contain" />
                : <MediaImage src={post.mediaUrl} alt={`Post by ${post.author.displayName}`} className="max-h-[560px] w-full object-contain" />}
            </div>}
          </>}
        <div className="mt-5 flex flex-wrap items-center gap-4 border-t border-border pt-4">
          <button onClick={toggleLike} disabled={like.isPending} aria-pressed={post.isLiked} data-testid={`button-like-post-${post.id}`} className={`inline-flex items-center gap-1.5 text-xs font-bold ${post.isLiked ? "text-accent" : "text-muted-foreground hover:text-accent"}`}><Heart className={`h-4 w-4 ${post.isLiked ? "fill-current" : ""}`} />{post.likeCount}</button>
          <button onClick={() => setCommentsOpen(!commentsOpen)} aria-expanded={commentsOpen} className="inline-flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-primary"><MessageCircle className="h-4 w-4" />{post.commentCount}</button>
          {mine && !editing && <div className="ml-auto flex gap-3"><button onClick={() => setEditing(true)} className="text-xs font-bold text-muted-foreground hover:text-primary">Edit</button><button onClick={deleteOwnPost} disabled={remove.isPending} className="text-xs font-bold text-destructive">{remove.isPending ? "Deleting…" : "Delete"}</button></div>}
        </div>
        {commentsOpen && <PostComments postId={post.id} onChanged={changed} />}
      </div>
    </div>
    {(update.isError || remove.isError || like.isError) && <p role="alert" className="mt-3 text-xs text-destructive">That action could not be saved. Please retry.</p>}
  </article>;
}

function FeedPage() {
  const client = useQueryClient();
  const current = useGetCurrentUser({ query: { enabled: Boolean(localStorage.getItem("babloshare-token")), queryKey: getGetCurrentUserQueryKey() } });
  const [content, setContent] = useState("");
  const [media, setMedia] = useState<UploadedMedia | null>(null);
  const [page, setPage] = useState(0);
  const limit = 20;
  const params = { limit, offset: page * limit };
  const posts = useListPosts(params, { query: { queryKey: getListPostsQueryKey(params) } });
  const create = useCreatePost();
  const refresh = () => client.invalidateQueries({ queryKey: ["/api/posts"] });
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!content.trim() && !media) return;
    create.mutate({ data: { content: content.trim(), mediaUrl: media?.mediaUrl ?? null, mediaType: media?.mediaType ?? null } }, { onSuccess: () => { setContent(""); setMedia(null); setPage(0); refresh(); } });
  };
  return <AppShell><div className="mx-auto max-w-3xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">The everyday loop / Posts</p>
    <h1 className="mt-2 font-display text-4xl font-bold tracking-[-.07em] sm:text-5xl">A place for<br /><span className="text-primary">the thought.</span></h1>
    <p className="mt-3 max-w-lg text-sm leading-6 text-muted-foreground">Text posts, comments, and likes are saved to your BABLOSHARE account.</p>
    {current.data && <form onSubmit={submit} className="mt-8 rounded-[26px] border border-border bg-card p-4 sm:p-5">
      <label htmlFor="feed-post-content" className="mb-2 block text-xs font-bold text-muted-foreground">Share a thought</label>
      <textarea id="feed-post-content" maxLength={2000} value={content} onChange={(event) => setContent(event.target.value)} placeholder="What is on your mind?" className="field min-h-24 resize-y py-3" />
      <div className="mt-3"><MediaGalleryPicker label="Add a photo or video" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime" onUploaded={setMedia} /></div>
      <div className="mt-3 flex items-center justify-between gap-3"><span className="text-xs text-muted-foreground">{content.length}/2000</span><button disabled={create.isPending || (!content.trim() && !media)} className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground disabled:opacity-50"><Send className="h-4 w-4" />{create.isPending ? "Publishing…" : "Publish post"}</button></div>
      {create.isError && <p role="alert" className="mt-3 text-sm text-destructive">Your post could not be published. Check the selected file and try again.</p>}
    </form>}
    {!current.data && <div className="mt-8 rounded-2xl bg-secondary p-4 text-sm">Sign in to publish, like, and comment. <Link href="/login" className="font-bold text-primary underline">Sign in</Link></div>}
    <div className="mt-7 space-y-4">
      {posts.isLoading ? <Status kind="loading" title="" body="" /> : posts.isError ? <Status kind="error" title="The feed is unavailable." body="Try again in a moment." retry={() => posts.refetch()} /> : !posts.data?.length ? <Status kind="empty" title="No posts yet." body="Start the conversation with the first post." /> : posts.data.map((post) => <FeedPostCard key={post.id} post={post} currentProfileId={current.data?.profile.id} changed={refresh} />)}
    </div>
    {posts.data?.length === limit && <div className="mt-6 flex justify-center"><button onClick={() => setPage(page + 1)} disabled={posts.isFetching} className="rounded-xl border border-border bg-card px-4 py-3 text-sm font-bold disabled:opacity-50">{posts.isFetching ? "Loading…" : "Load older posts"}</button></div>}
    {page > 0 && <div className="mt-3 flex justify-center"><button onClick={() => setPage(page - 1)} className="px-4 py-2 text-sm font-bold text-primary">Previous posts</button></div>}
  </div></AppShell>;
}

function notificationMessage(item: Notification) {
  switch (item.type) {
    case 'follow': return 'started following you';
    case 'post_like': return 'liked your post';
    case 'post_comment': return 'commented on your post';
    case 'video_like': return 'liked your video';
    case 'video_comment': return 'commented on your video';
  }
}

function NotificationsPage() {
  const client = useQueryClient();
  const token = Boolean(localStorage.getItem('babloshare-token'));
  const current = useGetCurrentUser({ query: { enabled: token, queryKey: getGetCurrentUserQueryKey() } });
  const query = useGetNotifications({ query: { enabled: token, queryKey: getGetNotificationsQueryKey() } });
  const markRead = useMarkNotificationsRead();
  const targetFor = (item: Notification) => item.type === 'follow'
    ? `/profile/${item.actor.username}`
    : item.entityType === 'post' ? '/feed' : '/watch';
  const markAll = () => markRead.mutate(undefined, {
    onSuccess: () => client.invalidateQueries({ queryKey: getGetNotificationsQueryKey() }),
  });
  return <AppShell><div className="mx-auto max-w-3xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">Your account / Updates</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.06em]">Notifications</h1><p className="mt-2 text-sm text-muted-foreground">{query.data ? `${query.data.unreadCount} unread` : 'Your latest follows and post interactions'}</p></div>
      {Boolean(query.data?.unreadCount) && <button onClick={markAll} disabled={markRead.isPending} className="rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-bold disabled:opacity-50">{markRead.isPending ? 'Updating…' : 'Mark all read'}</button>}
    </div>
    {!token && <div className="mt-8 rounded-2xl bg-secondary p-5 text-sm">Sign in to view notifications. <Link href="/login" className="font-bold text-primary underline">Sign in</Link></div>}
    {token && current.isError && <div className="mt-8"><Status kind="error" title="Your session could not be checked." body="Sign in again to see notifications." retry={() => current.refetch()} /></div>}
    {token && query.isLoading && <div className="mt-8"><Status kind="loading" title="" body="" /></div>}
    {token && query.isError && <div className="mt-8"><Status kind="error" title="Notifications could not load." body="Try again in a moment." retry={() => query.refetch()} /></div>}
    {token && query.data && !query.data.items.length && <div className="mt-8"><Status kind="empty" title="You're all caught up." body="New follows, likes, and comments will appear here." /></div>}
    {token && query.data?.items.length ? <div className="mt-7 space-y-3">{query.data.items.map((item) => <Link key={item.id} href={targetFor(item)} className={`flex gap-3 rounded-2xl border p-4 transition-colors hover:bg-card ${item.readAt ? 'border-border bg-card/60' : 'border-primary/30 bg-secondary/60'}`}>
      <Avatar profile={item.actor} size="sm" /><div className="min-w-0 flex-1"><p className="text-sm leading-5"><span className="font-bold">{item.actor.displayName}</span> {notificationMessage(item)}</p><p className="mt-1 font-mono-ui text-[10px] text-muted-foreground">{timeAgo(item.createdAt)} ago</p></div>{!item.readAt && <span aria-label="Unread" className="mt-1 h-2 w-2 shrink-0 rounded-full bg-accent" />}
    </Link>)}</div> : null}
    {markRead.isError && <p role="alert" className="mt-4 text-sm text-destructive">Notifications could not be marked read.</p>}
  </div></AppShell>;
}

function AdminPage() {
  const client = useQueryClient();
  const token = Boolean(localStorage.getItem('babloshare-token'));
  const current = useGetCurrentUser({ query: { enabled: token, queryKey: getGetCurrentUserQueryKey() } });
  const reports = useListAdminReports({ query: { enabled: token && current.data?.role === 'admin', queryKey: getListAdminReportsQueryKey() } });
  const users = useListAdminUsers({ query: { enabled: token && current.data?.role === 'admin', queryKey: getListAdminUsersQueryKey() } });
  const review = useReviewAdminReport();
  const setStatus = (id: string, status: 'resolved' | 'dismissed') => review.mutate({ id, data: { status } }, { onSuccess: () => client.invalidateQueries({ queryKey: getListAdminReportsQueryKey() }) });
  return <AppShell><div className="mx-auto max-w-5xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">Restricted workspace</p><h1 className="mt-2 flex items-center gap-3 font-display text-4xl font-bold tracking-[-.06em]"><ShieldCheck className="h-8 w-8 text-primary" />Administration</h1>
    {!token && <div className="mt-8 rounded-2xl bg-secondary p-5 text-sm">Sign in with an administrator account to continue. <Link href="/login" className="font-bold text-primary underline">Sign in</Link></div>}
    {token && current.isLoading && <div className="mt-8"><Status kind="loading" title="" body="" /></div>}
    {token && !current.isLoading && current.data?.role !== 'admin' && <div className="mt-8"><Status kind="error" title="Administrator access required." body="This area is restricted to accounts authorized by the platform owner." /></div>}
    {current.data?.role === 'admin' && <section className="mt-8">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><h2 className="font-display text-2xl font-bold">Conversation reports</h2><p className="mt-1 text-sm text-muted-foreground">Recent reports only; reporter email and private account details are not shown.</p></div><button onClick={() => reports.refetch()} disabled={reports.isFetching} className="rounded-xl border border-border bg-card px-4 py-2 text-sm font-bold">{reports.isFetching ? 'Refreshing…' : 'Refresh'}</button></div>
      {reports.isLoading ? <Status kind="loading" title="" body="" /> : reports.isError ? <Status kind="error" title="Reports could not load." body="Check your administrator access and retry." retry={() => reports.refetch()} /> : !reports.data?.length ? <Status kind="empty" title="No reports have been submitted." body="New member reports will appear here when they are filed." /> :
        <div className="space-y-3">{reports.data.map((report: AdminReport) => <article key={report.id} className="rounded-2xl border border-border bg-card p-5">
          <div className="flex flex-wrap items-start justify-between gap-3"><div className="flex min-w-0 items-center gap-3"><Avatar profile={report.reporter} size="sm" /><div><p className="text-sm font-bold">{report.reporter.displayName} reported a conversation</p><p className="mt-1 text-xs text-muted-foreground">{report.conversationTitle} · {timeAgo(report.createdAt)} ago</p></div></div><span className={`rounded-full px-3 py-1 font-mono-ui text-[10px] font-bold uppercase tracking-[.1em] ${report.status === 'open' ? 'bg-[#f9d9ce] text-destructive' : 'bg-secondary text-secondary-foreground'}`}>{report.status}</span></div>
          <p className="mt-4 whitespace-pre-wrap text-sm leading-6">{report.reason}</p>
          {report.status === 'open' && <div className="mt-4 flex flex-wrap justify-end gap-2"><button onClick={() => setStatus(report.id, 'dismissed')} disabled={review.isPending} className="rounded-xl border border-border px-3 py-2 text-xs font-bold">Dismiss report</button><button onClick={() => setStatus(report.id, 'resolved')} disabled={review.isPending} className="rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground">Mark resolved</button></div>}
        </article>)}</div>}
      {review.isError && <p role="alert" className="mt-4 text-sm text-destructive">The report status could not be updated.</p>}
      <div className="mt-12 mb-5"><h2 className="font-display text-2xl font-bold">Account moderation</h2><p className="mt-1 text-sm text-muted-foreground">Suspend or restore non-administrator accounts. Each action requires a reason and is recorded.</p></div>
      {users.isLoading ? <Status kind="loading" title="" body="" /> : users.isError ? <Status kind="error" title="Accounts could not load." body="Check your administrator access and retry." retry={() => users.refetch()} /> : !users.data?.length ? <Status kind="empty" title="No account records found." body="Account records will appear here when available." /> :
        <div className="space-y-3">{users.data.map((user: AdminUser) => <AdminUserRow key={user.id} user={user} onChanged={() => client.invalidateQueries({ queryKey: getListAdminUsersQueryKey() })} />)}</div>}
      <p className="mt-6 rounded-2xl bg-muted p-4 text-xs leading-5 text-muted-foreground">This dashboard reviews conversation reports and account status. Public post/video reporting is not enabled in this phase. Administrator privileges are assigned outside the app; users cannot grant themselves access, and administrator accounts cannot be suspended here.</p>
    </section>}
  </div></AppShell>;
}

function AdminUserRow({ user, onChanged }: { user: AdminUser; onChanged: () => void }) {
  const update = useUpdateAdminUserStatus();
  const [reason, setReason] = useState('');
  const nextStatus = user.accountStatus === 'active' ? 'suspended' : 'active';
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (reason.trim().length < 3 || user.role === 'admin') return;
    update.mutate({ id: user.id, data: { accountStatus: nextStatus, reason: reason.trim() } }, { onSuccess: () => { setReason(''); onChanged(); } });
  };
  return <article className="rounded-2xl border border-border bg-card p-4">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="font-bold">{user.displayName}</p><p className="mt-0.5 font-mono-ui text-xs text-muted-foreground">@{user.username} · {user.role}</p></div><span className={`rounded-full px-3 py-1 font-mono-ui text-[10px] font-bold uppercase ${user.accountStatus === 'active' ? 'bg-secondary text-secondary-foreground' : 'bg-[#f9d9ce] text-destructive'}`}>{user.accountStatus}</span></div>
    {user.role !== 'admin' && <form onSubmit={submit} className="mt-4 flex flex-col gap-2 sm:flex-row"><input required minLength={3} maxLength={500} value={reason} onChange={(event) => setReason(event.target.value)} aria-label={`Reason to ${nextStatus === 'suspended' ? 'suspend' : 'reactivate'} @${user.username}`} placeholder="Record a moderation reason" className="field h-10 flex-1" /><button disabled={update.isPending || reason.trim().length < 3} className={`rounded-xl px-3 py-2 text-xs font-bold ${nextStatus === 'suspended' ? 'bg-destructive text-white' : 'bg-primary text-primary-foreground'}`}>{update.isPending ? 'Saving…' : nextStatus === 'suspended' ? 'Suspend account' : 'Reactivate account'}</button></form>}
    {user.role === 'admin' && <p className="mt-3 text-xs text-muted-foreground">Administrator account status is managed outside this dashboard.</p>}
    {update.isError && <p role="alert" className="mt-3 text-xs text-destructive">Account status could not be updated.</p>}
  </article>;
}

function VideoActions({ video, onComment }: { video: Video; onComment: () => void }) {
  const client = useQueryClient();
  const like = useToggleVideoLike();
  const toggle = () => like.mutate({ id: video.id }, { onSuccess: () => client.invalidateQueries({ queryKey: getListVideosQueryKey() }) });
  return <div className="flex items-center gap-4 text-muted-foreground">
    <button onClick={toggle} disabled={like.isPending} data-testid={`button-like-${video.id}`} className={`flex items-center gap-1.5 text-xs font-bold transition-colors ${video.isLiked ? 'text-accent' : 'hover:text-accent'}`}><Heart className={`h-[18px] w-[18px] ${video.isLiked ? 'fill-current' : ''}`} />{formatCount(video.likeCount)}</button>
    <button onClick={onComment} data-testid={`button-comment-${video.id}`} className="flex items-center gap-1.5 text-xs font-bold hover:text-primary"><MessageCircle className="h-[18px] w-[18px]" />{formatCount(video.commentCount)}</button>
    <button data-testid={`button-share-${video.id}`} onClick={() => navigator.clipboard?.writeText(window.location.origin + `/watch?video=${video.id}`)} className="ml-auto hover:text-primary"><Share2 className="h-[17px] w-[17px]" /></button>
    <button data-testid={`button-bookmark-${video.id}`} className="hover:text-primary"><Bookmark className="h-[17px] w-[17px]" /></button>
  </div>;
}

function Comments({ videoId, onClose }: { videoId: string; onClose: () => void }) {
  const client = useQueryClient();
  const comments = useListVideoComments(videoId, { query: { queryKey: getListVideoCommentsQueryKey(videoId) } });
  const create = useCreateVideoComment();
  const [content, setContent] = useState('');
  const submit = (event: FormEvent) => { event.preventDefault(); if (!content.trim()) return; create.mutate({ id: videoId, data: { content } }, { onSuccess: () => { setContent(''); client.invalidateQueries({ queryKey: getListVideoCommentsQueryKey(videoId) }); } }); };
  return <div className="mt-4 rounded-2xl bg-muted/60 p-4" data-testid={`comments-${videoId}`}><div className="mb-3 flex items-center justify-between"><p className="font-display text-sm font-bold">The room</p><button onClick={onClose} data-testid={`button-close-comments-${videoId}`} className="text-xs font-bold text-muted-foreground">Close</button></div>
    {comments.isLoading ? <div className="h-10 animate-pulse rounded-xl bg-background" /> : comments.isError ? <p className="text-xs text-destructive">Comments are taking a moment.</p> : (comments.data || []).length === 0 ? <p className="mb-3 text-xs text-muted-foreground">Start the conversation.</p> : <div className="mb-3 max-h-40 space-y-3 overflow-auto">{(comments.data || []).map((comment: Comment) => <div key={comment.id} className="flex gap-2"><Avatar profile={comment.author} size="sm" /><div><p className="text-xs font-bold">{comment.author.displayName} <span className="ml-1 font-mono-ui font-normal text-muted-foreground">{timeAgo(comment.createdAt)}</span></p><p className="text-xs leading-5 text-muted-foreground">{comment.content}</p></div></div>)}</div>}
    <form onSubmit={submit} className="flex gap-2"><input value={content} onChange={(e) => setContent(e.target.value)} data-testid={`input-comment-${videoId}`} placeholder="Add your take..." className="h-9 min-w-0 flex-1 rounded-xl border border-input bg-background px-3 text-xs outline-none focus:border-primary" /><button disabled={create.isPending} data-testid={`button-submit-comment-${videoId}`} className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground"><Send className="h-3.5 w-3.5" /></button></form>
  </div>;
}

function ShortCard({ video }: { video: Video }) {
  const [commentsOpen, setCommentsOpen] = useState(false);
  return <article data-testid={`card-video-${video.id}`} className="appear overflow-hidden rounded-[28px] border border-border bg-card shadow-[0_10px_28px_rgba(43,35,69,.05)]">
    <div className="relative aspect-[4/4.4] overflow-hidden bg-[#2b2345]">
      <div className="absolute inset-0 bg-[linear-gradient(145deg,#2b2345,#147d78)]"><VideoPlayer video={video} className="h-full w-full object-cover" /></div>
      <div className="pointer-events-none absolute inset-0 media-shade" />
      <div className="pointer-events-none absolute left-5 top-5 flex items-center gap-2 rounded-full bg-[#2b2345]/70 px-2.5 py-1.5 text-[10px] font-bold text-white backdrop-blur"><Zap className="h-3 w-3 text-[#f1a27e]" /> SHORT / {timeAgo(video.createdAt)}</div>
      <div className="absolute inset-x-5 bottom-5 text-white"><div className="mb-3 flex items-center gap-2"><Avatar profile={video.creator} size="sm" /><Link href={`/profile/${video.creator.username}`} data-testid={`link-creator-${video.id}`} className="text-sm font-bold hover:underline">{video.creator.displayName}</Link>{video.creator.isVerified && <Verified />}</div><h3 className="font-display text-2xl font-bold leading-[1.05] tracking-[-.04em]">{video.title}</h3><p className="mt-2 line-clamp-2 text-xs leading-5 text-white/75">{video.description}</p></div>
    </div>
    <div className="p-4"><VideoActions video={video} onComment={() => setCommentsOpen(!commentsOpen)} />{commentsOpen && <Comments videoId={video.id} onClose={() => setCommentsOpen(false)} />}</div>
  </article>;
}

function LongCard({ video, featured = false }: { video: Video; featured?: boolean }) {
  return <article data-testid={`card-long-video-${video.id}`} className={`${featured ? 'md:col-span-2' : ''} group`}>
    <div className={`relative overflow-hidden rounded-[24px] bg-[#2b2345] ${featured ? 'aspect-[16/8]' : 'aspect-video'}`}>
      <VideoPlayer video={video} className="absolute inset-0 h-full w-full object-cover" />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#2b2345]/90 via-transparent to-transparent" /><div className="pointer-events-none absolute inset-x-5 bottom-5 flex items-end justify-between gap-3 text-white"><div><p className="mb-2 font-mono-ui text-[10px] uppercase tracking-[.16em] text-[#f1a27e]">Film / {formatCount(video.viewsCount)} tracked views</p><h3 className={`${featured ? 'text-2xl' : 'text-lg'} font-display font-bold leading-tight`}>{video.title}</h3></div></div>
    </div>
    <div className="mt-3 flex items-center gap-2"><Avatar profile={video.creator} size="sm" /><Link href={`/profile/${video.creator.username}`} data-testid={`link-long-creator-${video.id}`} className="text-xs font-bold hover:text-primary">{video.creator.displayName}</Link>{video.creator.isVerified && <Verified />}<span className="ml-auto text-xs text-muted-foreground">{timeAgo(video.createdAt)} ago</span></div>
  </article>;
}

function VideoPlayer({ video, className }: { video: Video; className: string }) {
  const client = useQueryClient();
  const record = useRecordVideoView();
  const startedAt = useRef<number | null>(null);
  const recorded = useRef(false);
  return <MediaVideo
    data-testid={`video-player-${video.id}`}
    src={video.playbackUrl}
    poster={video.thumbnailUrl || undefined}
    controls
    playsInline
    preload="metadata"
    className={className}
    onPlay={() => { if (startedAt.current === null) startedAt.current = Date.now(); }}
    onPause={() => { if (!recorded.current) startedAt.current = null; }}
    onEnded={() => { if (!recorded.current) startedAt.current = null; }}
    onTimeUpdate={(event) => {
      const player = event.currentTarget;
      if (recorded.current || !localStorage.getItem('babloshare-token') || player.currentTime < 5 || startedAt.current === null || Date.now() - startedAt.current < 5000) return;
      recorded.current = true;
      const elapsed = Math.max(0, Math.floor((Date.now() - startedAt.current) / 1000));
      record.mutate({ id: video.id, data: { watchSeconds: Math.min(Math.floor(player.currentTime), elapsed) } }, {
        onSuccess: () => {
          client.invalidateQueries({ queryKey: ['/api/economy/studio'] });
          client.invalidateQueries({ queryKey: getListVideosQueryKey() });
        },
        onError: () => { recorded.current = false; },
      });
    }}
  />;
}

function Explore() {
  const videos = useListVideos({ videoType: 'short', limit: 24 }, { query: { queryKey: getListVideosQueryKey({ videoType: 'short', limit: 24 }) } });
  return <AppShell><div className="mx-auto max-w-6xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <div className="mb-10 flex flex-wrap items-end justify-between gap-5"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">The open loop / 01</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.06em] sm:text-5xl">A little bit of<br /><span className="text-primary">everywhere.</span></h1><p className="mt-3 max-w-md text-sm leading-6 text-muted-foreground">Ideas in motion, from people making sense of their corner of the world.</p></div><div className="hidden items-center gap-2 rounded-2xl border border-border bg-card px-4 py-3 text-xs font-bold text-muted-foreground sm:flex"><span className="h-2 w-2 rounded-full bg-accent" /> Recent shares</div></div>
    {videos.isLoading ? <Status kind="loading" title="" body="" /> : videos.isError ? <Status kind="error" title="The loop paused." body="We couldn't bring in the latest shares." retry={() => videos.refetch()} /> : !videos.data?.length ? <Status kind="empty" title="It is quiet here." body="Be the first person to put a new idea in motion." /> : <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">{videos.data.map((video) => <ShortCard key={video.id} video={video} />)}</div>}
  </div></AppShell>;
}

function Watch() {
  const videos = useListVideos({ videoType: 'long', limit: 24 }, { query: { queryKey: getListVideosQueryKey({ videoType: 'long', limit: 24 }) } });
  return <AppShell><div className="mx-auto max-w-6xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <div className="mb-10 flex items-end justify-between gap-4"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">Sit with it / 02</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.06em] sm:text-5xl">More time.<br /><span className="text-accent">More to say.</span></h1></div><div className="hidden rounded-2xl bg-secondary px-4 py-3 text-xs font-bold text-secondary-foreground sm:block">Curated for curiosity</div></div>
    {videos.isLoading ? <Status kind="loading" title="" body="" /> : videos.isError ? <Status kind="error" title="The cinema is closed." body="Long-form shares are not available right now." retry={() => videos.refetch()} /> : !videos.data?.length ? <Status kind="empty" title="No films yet." body="The first long-form story is waiting for its maker." /> : <div className="grid gap-x-6 gap-y-10 md:grid-cols-2">{videos.data.map((video, index) => <LongCard key={video.id} video={video} featured={index === 0} />)}</div>}
  </div></AppShell>;
}

function SearchPage() {
  const [term, setTerm] = useState('');
  const [submitted, setSubmitted] = useState('');
  const params = useMemo(() => ({ q: submitted || 'discover', limit: 30 }), [submitted]);
  const results = useSearch(params, { query: { enabled: Boolean(submitted), queryKey: getSearchQueryKey(params) } });
  const submit = (event: FormEvent) => { event.preventDefault(); if (term.trim()) setSubmitted(term.trim()); };
  return <AppShell><div className="mx-auto max-w-5xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <div className="max-w-2xl"><p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">Find your people / 03</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.06em] sm:text-5xl">Follow the<br /><span className="text-primary">thread.</span></h1><form onSubmit={submit} className="mt-8 flex gap-2"><div className="relative flex-1"><Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><input value={term} onChange={(e) => setTerm(e.target.value)} data-testid="input-search" placeholder="Search creators, ideas, films..." className="h-14 w-full rounded-2xl border border-input bg-card pl-11 pr-4 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10" /></div><button type="submit" data-testid="button-submit-search" className="h-14 rounded-2xl bg-primary px-5 text-primary-foreground"><ArrowRight className="h-5 w-5" /></button></form></div>
    {!submitted ? <div className="mt-20 grid gap-4 sm:grid-cols-3"><div className="rounded-[26px] bg-primary p-6 text-primary-foreground sm:col-span-2"><Users className="mb-10 h-6 w-6" /><p className="font-display text-2xl font-bold tracking-[-.04em]">People who make you stop scrolling.</p><p className="mt-2 text-sm leading-6 text-primary-foreground/75">Search by a name, a place, or the idea you cannot shake.</p></div><div className="rounded-[26px] bg-secondary p-6"><Disc3 className="mb-10 h-6 w-6 text-accent" /><p className="font-display text-xl font-bold">No algorithmic fog.</p><p className="mt-2 text-sm leading-6 text-secondary-foreground/70">Just a better way to find a signal.</p></div></div> : results.isLoading ? <div className="mt-10"><Status kind="loading" title="" body="" /></div> : results.isError ? <div className="mt-10"><Status kind="error" title="Search missed the signal." body="Try a different phrase." retry={() => results.refetch()} /></div> : <SearchResults results={results.data} /> }
  </div></AppShell>;
}

function SearchResults({ results }: { results?: { profiles: Profile[]; videos: Video[] } }) {
  return <div className="mt-12 space-y-12" data-testid="search-results"><section><div className="mb-4 flex items-center justify-between"><h2 className="font-display text-xl font-bold">People</h2><span className="font-mono-ui text-xs text-muted-foreground">{results?.profiles.length || 0} found</span></div>{results?.profiles?.length ? <div className="grid gap-3 sm:grid-cols-2">{results.profiles.map((profile) => <Link href={`/profile/${profile.username}`} key={profile.id} data-testid={`card-search-profile-${profile.id}`} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4 transition-transform hover:-translate-y-0.5"><Avatar profile={profile} /><div className="min-w-0"><p className="truncate text-sm font-bold">{profile.displayName} {profile.isVerified && <Verified />}</p><p className="font-mono-ui text-xs text-muted-foreground">@{profile.username} · {formatCount(profile.followerCount)} followers</p></div><ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" /></Link>)}</div> : <p className="rounded-2xl border border-dashed border-border p-5 text-sm text-muted-foreground">No people matched that search.</p>}</section><section><div className="mb-4 flex items-center justify-between"><h2 className="font-display text-xl font-bold">Videos</h2><span className="font-mono-ui text-xs text-muted-foreground">{results?.videos.length || 0} found</span></div>{results?.videos?.length ? <div className="grid gap-6 sm:grid-cols-2">{results.videos.map((video) => <LongCard key={video.id} video={video} />)}</div> : <p className="rounded-2xl border border-dashed border-border p-5 text-sm text-muted-foreground">No videos matched that search.</p>}</section></div>;
}

function ProfilePage() {
  const { username = '' } = useParams<{ username: string }>();
  const client = useQueryClient();
  const [, setLocation] = useLocation();
  const profile = useGetProfile(username, { query: { queryKey: getGetProfileQueryKey(username) } });
  const videos = useListProfileVideos(username, { query: { queryKey: getListProfileVideosQueryKey(username) } });
  const current = useGetCurrentUser({ query: { enabled: Boolean(localStorage.getItem('babloshare-token')), queryKey: getGetCurrentUserQueryKey() } });
  const follow = useToggleFollow();
  const updateProfile = useUpdateMyProfile();
  const offer = useGetCreatorOffer(username, { query: { queryKey: getGetCreatorOfferQueryKey(username), enabled: Boolean(profile.data?.isCreator), retry: false } });
  const tip = useCreateTipCheckout();
  const subscribe = useCreateSubscriptionCheckout();
  const confirmCheckout = useConfirmEconomyCheckout();
  const [tab, setTab] = useState<'videos' | 'about'>('videos');
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ username: '', displayName: '', bio: '', avatarUrl: '', coverUrl: '' });
  const [tipAmount, setTipAmount] = useState('5');
  const [tipMessage, setTipMessage] = useState('');
  const [paymentNotice, setPaymentNotice] = useState('');
  const confirmedSession = useRef('');
  const params = new URLSearchParams(window.location.search);
  const checkoutSessionId = params.get('tip_session') || params.get('subscription_session');
  useEffect(() => {
    if (!checkoutSessionId || !localStorage.getItem('babloshare-token') || confirmedSession.current === checkoutSessionId) return;
    confirmedSession.current = checkoutSessionId;
    confirmCheckout.mutate({ sessionId: checkoutSessionId }, {
      onSuccess: (result) => {
        setPaymentNotice(result.status === 'verified' ? 'Stripe confirmed your payment. The creator ledger is updated from verified transaction data.' : result.status === 'pending' ? 'Stripe is still confirming the payment. The creator ledger will update when payment is verified.' : 'This checkout could not be verified for your account.');
      },
      onError: () => setPaymentNotice('The checkout could not be verified. If payment was completed, Stripe’s webhook will still reconcile it.'),
    });
  }, [checkoutSessionId]);
  const toggle = () => follow.mutate({ username }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetProfileQueryKey(username) }); } });
  const submitProfileEdit = (event: FormEvent) => {
    event.preventDefault();
    const body = {
      username: editForm.username.trim(),
      displayName: editForm.displayName.trim(),
      bio: editForm.bio,
      avatarUrl: editForm.avatarUrl.trim() || null,
      coverUrl: editForm.coverUrl.trim() || null,
    };
    updateProfile.mutate({ data: body }, { onSuccess: (updated) => {
      client.invalidateQueries({ queryKey: getGetCurrentUserQueryKey() });
      client.invalidateQueries({ queryKey: getGetProfileQueryKey(username) });
      setEditing(false);
      setLocation(`/profile/${updated.username}`);
    } });
  };
  const startProfileEdit = () => {
    if (!profile.data) return;
    setEditForm({ username: profile.data.username, displayName: profile.data.displayName, bio: profile.data.bio, avatarUrl: profile.data.avatarUrl || '', coverUrl: profile.data.coverUrl || '' });
    setEditing(true);
  };
  const checkout = (kind: 'tip' | 'subscription') => {
    const redirect = (checkoutUrl: string) => { window.location.assign(checkoutUrl); };
    if (kind === 'tip') {
      const amountMinor = Math.round(Number(tipAmount) * 100);
      if (!Number.isFinite(amountMinor) || amountMinor < 100) return;
      tip.mutate({ data: { creatorUsername: username, amountMinor, ...(tipMessage.trim() ? { message: tipMessage.trim() } : {}) } }, { onSuccess: (result) => redirect(result.checkoutUrl) });
    } else {
      subscribe.mutate({ data: { creatorUsername: username } }, { onSuccess: (result) => redirect(result.checkoutUrl) });
    }
  };
  if (profile.isLoading) return <AppShell><div className="mx-auto max-w-5xl px-5 py-12"><Status kind="loading" title="" body="" /></div></AppShell>;
  if (profile.isError || !profile.data) return <AppShell><div className="mx-auto max-w-5xl px-5 py-12"><Status kind="error" title="Profile not found." body="This person may have moved their corner of the internet." /></div></AppShell>;
  const person = profile.data;
  const isOwnProfile = current.data?.profile.userId === person.userId;
  return <AppShell><div className="mx-auto max-w-5xl px-5 py-8 sm:px-8 lg:px-12 lg:py-12">
    <div className="relative overflow-hidden rounded-[30px] border border-border bg-card">
      <div className="h-36 bg-[linear-gradient(115deg,#147d78,#2b2345_60%,#f1a27e)] sm:h-48">{person.coverUrl && <MediaImage src={person.coverUrl} alt="" className="h-full w-full object-cover opacity-80" />}</div>
      <div className="px-5 pb-6 sm:px-8"><div className="-mt-10 flex flex-wrap items-end justify-between gap-4 sm:-mt-12"><Avatar profile={person} size="lg" />{isOwnProfile ? <div className="flex gap-2"><button onClick={startProfileEdit} className="rounded-xl border border-border bg-background px-4 py-2.5 text-sm font-bold">Edit profile</button><Link href="/studio" className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground">Creator Studio</Link></div> : <button onClick={toggle} disabled={follow.isPending || !current.data} data-testid="button-toggle-follow" className={`rounded-xl px-4 py-2.5 text-sm font-bold ${person.isFollowing ? 'border border-border bg-background text-foreground' : 'bg-primary text-primary-foreground'}`}>{person.isFollowing ? 'Following' : current.data ? 'Follow' : 'Sign in to follow'}</button>}</div><div className="mt-4"><div className="flex items-center gap-2"><h1 data-testid="text-profile-name" className="font-display text-3xl font-bold tracking-[-.05em]">{person.displayName}</h1>{person.isVerified && <Verified />}</div><p data-testid="text-profile-username" className="mt-1 font-mono-ui text-xs text-muted-foreground">@{person.username}</p><p className="mt-4 max-w-xl text-sm leading-6 text-muted-foreground">{person.bio || 'Making room for better questions.'}</p><div className="mt-5 flex gap-6"><div><span className="font-display text-lg font-bold">{formatCount(person.followerCount)}</span><span className="ml-1 text-xs text-muted-foreground">followers</span></div><div><span className="font-display text-lg font-bold">{formatCount(person.followingCount)}</span><span className="ml-1 text-xs text-muted-foreground">following</span></div>{person.isCreator && <span className="rounded-full bg-secondary px-3 py-1.5 font-mono-ui text-[10px] font-bold uppercase tracking-[.15em] text-secondary-foreground">Creator</span>}</div></div></div>
    </div>
    {person.isCreator && !isOwnProfile && <section className="mt-5 rounded-[25px] border border-border bg-card p-5">
      <h2 className="font-display text-lg font-bold">Support this creator</h2>
      {paymentNotice && <p role="status" className="mt-3 rounded-xl bg-secondary p-3 text-sm">{paymentNotice}</p>}
      {!current.data ? <div className="mt-3 rounded-xl bg-muted p-4 text-sm">Sign in to send a tip or subscribe. <Link href="/login" className="font-bold text-primary underline">Sign in</Link></div> :
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <form onSubmit={(event) => { event.preventDefault(); checkout('tip'); }} className="space-y-3 rounded-2xl bg-muted/60 p-4">
          <p className="text-sm font-bold">Send a one-time tip</p>
          <label className="block"><span className="mb-1 block text-xs font-semibold">Amount in USD</span><input type="number" min="1" max="10000" step="0.01" required value={tipAmount} onChange={(event) => setTipAmount(event.target.value)} className="field h-11" /></label>
          <label className="block"><span className="mb-1 block text-xs font-semibold">Message (optional)</span><input maxLength={240} value={tipMessage} onChange={(event) => setTipMessage(event.target.value)} className="field h-11" /></label>
          <button disabled={tip.isPending} className="w-full rounded-xl bg-primary px-3 py-2.5 text-sm font-bold text-primary-foreground">{tip.isPending ? 'Opening Stripe…' : 'Continue to Stripe'}</button>
          {tip.isError && <p role="alert" className="text-xs text-destructive">Tip checkout could not be started.</p>}
        </form>
        {offer.data?.active && <div className="flex flex-col rounded-2xl bg-secondary/70 p-4"><p className="text-sm font-bold">{offer.data.name}</p><p className="mt-2 text-sm leading-5 text-muted-foreground">{offer.data.description || 'Creator membership'}</p><p className="mt-auto pt-4 font-display text-2xl font-bold">{new Intl.NumberFormat(undefined, { style: 'currency', currency: offer.data.currency.toUpperCase() }).format(offer.data.amountMinor / 100)}<span className="ml-1 text-sm font-semibold text-muted-foreground">/{offer.data.interval}</span></p><button onClick={() => checkout('subscription')} disabled={subscribe.isPending} className="mt-3 w-full rounded-xl bg-accent px-3 py-2.5 text-sm font-bold text-white">{subscribe.isPending ? 'Opening Stripe…' : 'Subscribe'}</button>{subscribe.isError && <p role="alert" className="mt-2 text-xs text-destructive">Subscription checkout could not be started.</p>}</div>}
        {offer.isError && <p className="self-center text-sm text-muted-foreground sm:col-span-2">This creator has not set up a subscription offer.</p>}
      </div>}
    </section>}
    {editing && <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#2b2345]/35 p-0 backdrop-blur-sm sm:items-center sm:p-6"><form onSubmit={submitProfileEdit} className="w-full max-w-lg space-y-3 rounded-t-[30px] border border-border bg-card p-6 shadow-2xl sm:rounded-[30px]"><div className="flex items-start justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">Your account</p><h2 className="mt-1 font-display text-2xl font-bold">Edit profile</h2></div><button type="button" aria-label="Close profile editor" onClick={() => setEditing(false)} className="rounded-xl p-2 text-muted-foreground hover:bg-muted"><X className="h-5 w-5" /></button></div>
      <label className="block"><span className="mb-1 block text-xs font-bold">Display name</span><input required maxLength={80} value={editForm.displayName} onChange={(event) => setEditForm({ ...editForm, displayName: event.target.value })} className="field" /></label>
      <label className="block"><span className="mb-1 block text-xs font-bold">Username</span><input required minLength={3} maxLength={32} value={editForm.username} onChange={(event) => setEditForm({ ...editForm, username: event.target.value })} className="field" /></label>
      <label className="block"><span className="mb-1 block text-xs font-bold">Biography</span><textarea maxLength={500} value={editForm.bio} onChange={(event) => setEditForm({ ...editForm, bio: event.target.value })} className="field min-h-20 resize-y py-3" /></label>
      <MediaGalleryPicker label="Profile photo" onUploaded={(media) => setEditForm({ ...editForm, avatarUrl: media.mediaUrl })} />
      <MediaGalleryPicker label="Cover photo" onUploaded={(media) => setEditForm({ ...editForm, coverUrl: media.mediaUrl })} />
      {updateProfile.isError && <p role="alert" className="text-sm text-destructive">Profile changes could not be saved. The username may already be taken.</p>}
      <button disabled={updateProfile.isPending} className="w-full rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground">{updateProfile.isPending ? 'Saving…' : 'Save profile'}</button>
    </form></div>}
    <div className="mt-8 flex gap-6 border-b border-border"><button onClick={() => setTab('videos')} data-testid="button-profile-videos-tab" className={`border-b-2 pb-3 text-sm font-bold ${tab === 'videos' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground'}`}>Videos</button><button onClick={() => setTab('about')} data-testid="button-profile-about-tab" className={`border-b-2 pb-3 text-sm font-bold ${tab === 'about' ? 'border-primary text-primary' : 'border-transparent text-muted-foreground'}`}>About</button></div>
    {tab === 'about' ? <div className="mt-8 max-w-xl rounded-[25px] bg-secondary p-6"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-secondary-foreground/65">A little more</p><p className="mt-4 font-display text-2xl font-bold leading-tight">{person.bio || 'No bio yet. The work says enough.'}</p><p className="mt-6 text-sm leading-6 text-secondary-foreground/70">Follow @{person.username} to keep their ideas in your orbit.</p></div> : videos.isLoading ? <div className="mt-8"><Status kind="loading" title="" body="" /></div> : videos.isError ? <div className="mt-8"><Status kind="error" title="Could not load uploads." body="Try coming back in a moment." retry={() => videos.refetch()} /></div> : !videos.data?.length ? <div className="mt-8"><Status kind="empty" title="Nothing shared yet." body="When this creator publishes, it will land here." /></div> : <div className="mt-8 grid gap-6 sm:grid-cols-2">{videos.data.map((video) => <LongCard key={video.id} video={video} />)}</div>}
  </div></AppShell>;
}

function Landing() {
  return <div className="grain min-h-[100dvh] overflow-hidden bg-[#f6f0e5] text-[#2b2345]"><header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-6 sm:px-8"><Logo /><div className="flex items-center gap-3"><Link href="/login" data-testid="link-landing-login" className="hidden px-3 py-2 text-sm font-bold sm:block">Sign in</Link><Link href="/register" data-testid="link-landing-register" className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-[3px_3px_0_0_#f1a27e]">Join the loop <ArrowRight className="ml-1 inline h-4 w-4" /></Link></div></header>
    <main><section className="relative mx-auto max-w-7xl px-5 pb-20 pt-12 sm:px-8 sm:pt-20 lg:min-h-[650px] lg:pt-28"><div className="max-w-3xl"><p className="appear font-mono-ui text-[11px] uppercase tracking-[.25em] text-primary">A social video network for curious people</p><h1 className="appear appear-delay-1 mt-6 font-display text-[clamp(4rem,11vw,9rem)] font-bold leading-[.83] tracking-[-.09em]">Make your<br /><span className="text-primary">mark.</span></h1><p className="appear appear-delay-2 mt-8 max-w-md text-lg leading-8 text-[#2b2345]/70">A place for the half-formed thought, the finished film, and the people who make you see things differently.</p><div className="appear appear-delay-3 mt-9 flex flex-wrap items-center gap-4"><Link href="/register" data-testid="link-hero-register" className="rounded-2xl bg-accent px-6 py-4 text-sm font-extrabold text-white shadow-[5px_5px_0_0_#2b2345] transition-transform hover:-translate-y-1">Start sharing <ArrowRight className="ml-2 inline h-4 w-4" /></Link><Link href="/explore" data-testid="link-hero-explore" className="rounded-2xl border border-[#2b2345]/20 px-6 py-4 text-sm font-bold">Look around first</Link></div></div><div className="pointer-events-none absolute -right-24 top-24 hidden h-[500px] w-[500px] rotate-6 rounded-[42%] bg-primary lg:block"><div className="absolute inset-10 rounded-[38%] border-[2px] border-[#f6f0e5]/35" /><div className="absolute bottom-12 left-16 max-w-[210px] -rotate-6 font-display text-3xl font-bold leading-none text-[#f6f0e5]">Ideas look better in motion.</div><div className="absolute right-20 top-16 flex h-24 w-24 -rotate-12 items-center justify-center rounded-full bg-[#f1a27e] text-center font-mono-ui text-[10px] font-bold uppercase tracking-widest text-[#2b2345]">Made for<br />the in-between</div></div></section>
      <section className="border-y border-[#2b2345]/10 bg-[#2b2345] px-5 py-5 text-[#f6f0e5] sm:px-8"><div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4"><p className="font-mono-ui text-xs uppercase tracking-[.2em] text-[#f1a27e]">Connect. Create. Share.</p><p className="text-sm text-[#f6f0e5]/65">A calmer internet starts with better signals.</p></div></section>
      <section className="mx-auto grid max-w-7xl gap-5 px-5 py-20 sm:px-8 lg:grid-cols-[1.2fr_.8fr] lg:py-28"><div className="rounded-[30px] bg-secondary p-8 sm:p-12"><Sparkles className="h-7 w-7 text-accent" /><p className="mt-20 max-w-lg font-display text-4xl font-bold leading-[.98] tracking-[-.06em] sm:text-6xl">Your feed should feel like a good conversation.</p><p className="mt-6 max-w-sm text-sm leading-6 text-secondary-foreground/70">Short bursts when you are passing through. Longer stories when you have somewhere to be.</p></div><div className="flex flex-col justify-between rounded-[30px] bg-primary p-8 text-primary-foreground sm:p-12"><div><Eye className="h-7 w-7" /><p className="mt-16 font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary-foreground/65">No performance required</p><p className="mt-3 font-display text-3xl font-bold leading-tight">Make something real. Let it travel.</p></div><Link href="/register" data-testid="link-section-register" className="mt-12 flex items-center justify-between border-t border-primary-foreground/20 pt-5 text-sm font-bold">Find your people <ArrowRight className="h-5 w-5" /></Link></div></section>
      <footer className="mx-auto flex max-w-7xl flex-col gap-4 border-t border-[#2b2345]/10 px-5 py-8 sm:flex-row sm:items-center sm:justify-between sm:px-8"><Logo /><p className="font-mono-ui text-[10px] uppercase tracking-[.17em] text-[#2b2345]/50">Connect. Create. Share.</p></footer>
    </main>
  </div>;
}

function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const [, setLocation] = useLocation();
  const client = useQueryClient();
  const login = useLogin();
  const register = useRegister();
  const [form, setForm] = useState({ email: '', password: '', username: '', displayName: '' });
  const isRegister = mode === 'register';
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (isRegister) register.mutate({ data: form }, { onSuccess: (response) => { localStorage.setItem('babloshare-token', response.token); client.setQueryData(getGetCurrentUserQueryKey(), response.user); setLocation('/explore'); } });
    else login.mutate({ data: form }, { onSuccess: (response) => { localStorage.setItem('babloshare-token', response.token); client.setQueryData(getGetCurrentUserQueryKey(), response.user); setLocation('/explore'); } });
  };
  const pending = login.isPending || register.isPending;
  const error = login.isError || register.isError;
  return <div className="grain grid min-h-[100dvh] bg-[#f6f0e5] lg:grid-cols-[.9fr_1.1fr]"><div className="hidden bg-primary p-12 text-primary-foreground lg:flex lg:flex-col lg:justify-between"><Logo inverted /><div><p className="font-mono-ui text-[10px] uppercase tracking-[.25em] text-primary-foreground/60">The open loop</p><h1 className="mt-5 max-w-md font-display text-7xl font-bold leading-[.88] tracking-[-.08em]">There is room for your point of view.</h1><p className="mt-8 max-w-sm text-sm leading-6 text-primary-foreground/70">BABLOSHARE is for people who want to find good work and leave the internet a little better than they found it.</p></div><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary-foreground/60">Connect. Create. Share.</p></div><div className="flex flex-col px-5 py-6 sm:px-10 lg:px-20"><Logo /><div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-12"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-primary">{isRegister ? 'Make your entrance' : 'Welcome back'}</p><h1 className="mt-3 font-display text-4xl font-bold tracking-[-.06em]">{isRegister ? 'Start your loop.' : 'Pick up where you left off.'}</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">{isRegister ? 'A username, a point of view, and somewhere to put it.' : 'The good stuff is still here.'}</p><form onSubmit={submit} className="mt-9 space-y-4" data-testid={`form-${mode}`}><label className="block"><span className="mb-2 block text-xs font-bold">Email</span><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} data-testid="input-auth-email" className="h-12 w-full rounded-2xl border border-input bg-card px-4 text-sm outline-none focus:border-primary" placeholder="you@example.com" /></label>{isRegister && <div className="grid gap-4 sm:grid-cols-2"><label className="block"><span className="mb-2 block text-xs font-bold">Display name</span><input required value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} data-testid="input-auth-display-name" className="h-12 w-full rounded-2xl border border-input bg-card px-4 text-sm outline-none focus:border-primary" placeholder="Your name" /></label><label className="block"><span className="mb-2 block text-xs font-bold">Username</span><input required minLength={3} value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} data-testid="input-auth-username" className="h-12 w-full rounded-2xl border border-input bg-card px-4 text-sm outline-none focus:border-primary" placeholder="yourhandle" /></label></div>}<label className="block"><span className="mb-2 block text-xs font-bold">Password</span><input required minLength={8} type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} data-testid="input-auth-password" className="h-12 w-full rounded-2xl border border-input bg-card px-4 text-sm outline-none focus:border-primary" placeholder="At least 8 characters" /></label>{error && <p data-testid="status-auth-error" className="rounded-xl bg-[#f9d9ce] px-3 py-2 text-xs font-semibold text-destructive">We could not sign you in with those details. Please check and try again.</p>}<button disabled={pending} data-testid={`button-submit-${mode}`} className="flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-primary font-bold text-primary-foreground disabled:opacity-60">{pending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : isRegister ? 'Create my account' : 'Sign in'}</button></form><p className="mt-7 text-center text-sm text-muted-foreground">{isRegister ? 'Already have an account?' : 'New to BABLOSHARE?'} <Link href={isRegister ? '/login' : '/register'} data-testid={`link-switch-${mode}`} className="font-bold text-primary underline underline-offset-4">{isRegister ? 'Sign in' : 'Create one'}</Link></p></div></div></div>;
}

function Router() {
  const [location] = useLocation();
  const isPublic = location === '/' || location === '/login' || location === '/register';
  return <ErrorBoundary resetKey={location}><Switch><Route path="/" component={Landing} /><Route path="/login"><AuthPage mode="login" /></Route><Route path="/register"><AuthPage mode="register" /></Route><Route path="/explore" component={Explore} /><Route path="/feed" component={FeedPage} /><Route path="/notifications" component={NotificationsPage} /><Route path="/admin" component={AdminPage} /><Route path="/watch" component={Watch} /><Route path="/search" component={SearchPage} /><Route path="/profile/:username" component={ProfilePage} /><Route path="/studio" component={CreatorStudio} /><Route path="/community" component={CommunityPage} /><Route path="/groups/:id" component={GroupPage} /><Route path="/pages" component={PagesPage} /><Route path="/pages/:username" component={PageProfile} /><Route path="/stories" component={StoriesPage} /><Route path="/inbox" component={InboxPage} /><Route component={NotFound} /></Switch>{!isPublic && null}</ErrorBoundary>;
}

function App() {
  useEffect(() => { setAuthTokenGetter(() => localStorage.getItem('babloshare-token')); }, []);
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;