import { useState, type FormEvent } from "react";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  getGetCreatorStudioQueryKey,
  getGetCreatorWalletQueryKey,
  getGetCurrentUserQueryKey,
  getGetCreatorOfferQueryKey,
  useCreateCreatorOffer,
  useGetCreatorOffer,
  useGetCreatorStudio,
  useGetCreatorWallet,
  useGetCurrentUser,
} from "@workspace/api-client-react";
import { ArrowLeft, BadgeDollarSign, ChartNoAxesCombined, CircleDollarSign, Eye, FileText, Heart, Plus, Sparkles } from "lucide-react";

const ink = "#2b2345";

function money(minor: number, currency = "USD") {
  return new Intl.NumberFormat(undefined, { style: "currency", currency }).format(minor / 100);
}

function duration(seconds: number) {
  const mins = Math.floor(seconds / 60);
  const hours = Math.floor(mins / 60);
  return hours ? `${hours}h ${mins % 60}m` : mins ? `${mins}m` : `${seconds}s`;
}

function StudioShell({ children }: { children: React.ReactNode }) {
  return <div className="grain min-h-[100dvh] bg-background">
    <header className="sticky top-0 z-20 border-b border-border/70 bg-background/90 px-5 py-4 backdrop-blur-lg">
      <div className="mx-auto flex max-w-6xl items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5" aria-label="BABLOSHARE home">
          <span className="flex h-9 w-9 items-center justify-center rounded-[13px] bg-primary font-display text-lg font-bold text-primary-foreground shadow-[4px_4px_0_0_#f1a27e]">B</span>
          <span className="font-display text-xl font-bold tracking-[-.06em]">BABLO<span className="text-primary">SHARE</span></span>
        </Link>
        <Link href="/explore" className="flex items-center gap-2 rounded-xl border border-border px-3 py-2 text-xs font-bold text-muted-foreground"><ArrowLeft className="h-3.5 w-3.5" /> Main loop</Link>
      </div>
    </header>
    <main className="mx-auto max-w-6xl px-5 py-8 pb-20 sm:px-8 lg:py-12">{children}</main>
  </div>;
}

function Metric({ icon: Icon, label, value, note }: { icon: typeof Eye; label: string; value: string; note: string }) {
  return <article className="rounded-[24px] border border-border bg-card p-5 sm:p-6">
    <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary"><Icon className="h-4 w-4" /></span>{label}</div>
    <p className="mt-5 font-display text-3xl font-bold tracking-[-.05em]">{value}</p>
    <p className="mt-1 text-xs leading-5 text-muted-foreground">{note}</p>
  </article>;
}

function OfferForm({ username }: { username: string }) {
  const client = useQueryClient();
  const create = useCreateCreatorOffer();
  const [name, setName] = useState("Creator membership");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("5");
  const [interval, setInterval] = useState<"month" | "year">("month");
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const amountMinor = Math.round(Number(price) * 100);
    if (!Number.isFinite(amountMinor) || amountMinor < 100) return;
    create.mutate({ data: { name, description, amountMinor, interval } }, {
      onSuccess: () => client.invalidateQueries({ queryKey: getGetCreatorOfferQueryKey(username) }),
    });
  };
  return <form onSubmit={submit} className="space-y-3">
    <label className="block"><span className="mb-1.5 block text-xs font-bold">Membership name</span><input required maxLength={80} value={name} onChange={(event) => setName(event.target.value)} className="field" /></label>
    <label className="block"><span className="mb-1.5 block text-xs font-bold">What members get</span><textarea maxLength={500} value={description} onChange={(event) => setDescription(event.target.value)} className="field min-h-20 resize-y py-3" /></label>
    <div className="grid grid-cols-[1fr_1fr] gap-3">
      <label className="block"><span className="mb-1.5 block text-xs font-bold">Price in USD</span><input required type="number" min="1" max="10000" step="0.01" value={price} onChange={(event) => setPrice(event.target.value)} className="field" /></label>
      <label className="block"><span className="mb-1.5 block text-xs font-bold">Billing period</span><select value={interval} onChange={(event) => setInterval(event.target.value as typeof interval)} className="field"><option value="month">Monthly</option><option value="year">Yearly</option></select></label>
    </div>
    <p className="text-xs leading-5 text-muted-foreground">Checkout and recurring billing are handled by Stripe. No payout method is configured here.</p>
    {create.isError && <p role="alert" className="text-sm text-destructive">Stripe could not create this offer. Please try again.</p>}
    <button disabled={create.isPending} className="inline-flex items-center gap-2 rounded-2xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"><Plus className="h-4 w-4" />{create.isPending ? "Creating offer…" : "Create subscription offer"}</button>
  </form>;
}

export default function CreatorStudio() {
  const current = useGetCurrentUser({ query: { queryKey: getGetCurrentUserQueryKey() } });
  const studio = useGetCreatorStudio({ query: { queryKey: getGetCreatorStudioQueryKey(), enabled: Boolean(localStorage.getItem("babloshare-token")) } });
  const wallet = useGetCreatorWallet({ query: { queryKey: getGetCreatorWalletQueryKey(), enabled: Boolean(localStorage.getItem("babloshare-token")) } });
  const username = current.data?.profile.username ?? "";
  const offer = useGetCreatorOffer(username, { query: { queryKey: getGetCreatorOfferQueryKey(username), enabled: Boolean(username), retry: false } });
  if (current.isError || !localStorage.getItem("babloshare-token")) {
    return <StudioShell><div className="mx-auto max-w-lg rounded-[28px] border border-dashed border-border p-8 text-center"><h1 className="font-display text-2xl font-bold">Sign in to open Creator Studio</h1><Link href="/login" className="mt-4 inline-flex rounded-xl bg-primary px-4 py-3 text-sm font-bold text-primary-foreground">Sign in</Link></div></StudioShell>;
  }
  const hasOffer = Boolean(offer.data?.active);
  return <StudioShell>
    <div className="flex flex-wrap items-end justify-between gap-5">
      <div><p className="font-mono-ui text-[10px] uppercase tracking-[.22em] text-primary">Creator tools / 08</p><h1 className="mt-2 font-display text-4xl font-bold tracking-[-.07em] sm:text-6xl">Make the work.<br /><span className="text-primary">Know what travels.</span></h1><p className="mt-4 max-w-xl text-sm leading-6 text-muted-foreground">Your metrics come from saved videos, playback events, followers, and confirmed Stripe transactions. No estimates or seeded earnings.</p></div>
      {username && <Link href={`/profile/${username}`} className="rounded-2xl border border-border bg-card px-4 py-3 text-sm font-bold">View your profile</Link>}
    </div>

    <section className="mt-9 grid gap-3 sm:grid-cols-2 xl:grid-cols-3" aria-label="Creator analytics">
      {studio.isLoading ? <div className="col-span-full rounded-2xl bg-muted p-6 text-sm text-muted-foreground">Loading actual creator metrics…</div> : studio.isError || !studio.data ? <div role="alert" className="col-span-full rounded-2xl border border-dashed border-border p-6 text-sm text-destructive">Creator analytics are unavailable right now.</div> : <>
        <Metric icon={Eye} label="Tracked video views" value={studio.data.totalViews.toLocaleString()} note="Recorded in the platform database" />
        <Metric icon={ChartNoAxesCombined} label="Playback time" value={duration(studio.data.watchTimeSeconds)} note="Reported by signed-in playback events" />
        <Metric icon={Sparkles} label="Audience reach" value={studio.data.audienceReach.toLocaleString()} note="Tracked unique viewers across your videos" />
        <Metric icon={CircleDollarSign} label="Followers" value={current.isLoading ? "…" : current.data ? current.data.profile.followerCount.toLocaleString() : "Unavailable"} note="Current database-backed follower count" />
        <Metric icon={FileText} label="Text posts" value={studio.data.publishedPosts.toLocaleString()} note="Posts authored from your account" />
        <Metric icon={Heart} label="Likes" value={studio.data.totalLikes.toLocaleString()} note="Current likes on your videos and posts" />
      </>}
    </section>

    <section className="mt-6 grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
      <div className="rounded-[26px] border border-border bg-card p-5 sm:p-7">
        <div className="mb-5 flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary text-primary"><BadgeDollarSign className="h-5 w-5" /></span><div><h2 className="font-display text-xl font-bold">Creator wallet</h2><p className="text-xs text-muted-foreground">Gross confirmed payments, before Stripe fees; not a payout balance.</p></div></div>
        {wallet.isLoading ? <p className="py-5 text-sm text-muted-foreground">Loading ledger totals…</p> : wallet.isError || !wallet.data ? <p role="alert" className="py-5 text-sm text-destructive">Wallet totals are unavailable.</p> : <div className="grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-secondary/60 p-4"><p className="text-xs font-bold text-muted-foreground">Confirmed gross</p><p className="mt-2 font-display text-2xl font-bold">{money(wallet.data.availableBalanceMinor)}</p></div>
          <div className="rounded-2xl bg-muted p-4"><p className="text-xs font-bold text-muted-foreground">Pending</p><p className="mt-2 font-display text-2xl font-bold">{money(wallet.data.pendingEarningsMinor)}</p></div>
        </div>}
        <div className="mt-6 border-t border-border pt-5"><h3 className="font-display text-base font-bold">Verified transactions</h3>
          {!wallet.data?.transactions.length ? <p className="mt-3 rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">No verified creator transactions yet.</p> : <ul className="mt-2 divide-y divide-border">{wallet.data.transactions.map((entry) => <li key={entry.id} className="flex items-center justify-between gap-3 py-3 text-sm"><div className="min-w-0"><p className="truncate font-bold">{entry.description}</p><p className="mt-1 text-xs capitalize text-muted-foreground">{entry.entryType} · {entry.status} · {new Date(entry.createdAt).toLocaleDateString()}</p></div><span className="shrink-0 font-mono-ui font-bold">{money(entry.amountMinor)}</span></li>)}</ul>}
        </div>
      </div>

      <div className="rounded-[26px] border border-border bg-card p-5 sm:p-7">
        <h2 className="font-display text-xl font-bold">Subscription offer</h2>
        <p className="mb-5 mt-1 text-sm leading-6 text-muted-foreground">Set a real recurring price. Stripe creates the product and price; this app stores only their identifiers.</p>
        {hasOffer ? <div className="rounded-2xl bg-secondary/60 p-4"><p className="font-bold">{offer.data?.name}</p><p className="mt-1 text-sm text-muted-foreground">{offer.data?.description || "Active creator subscription"}</p><p className="mt-3 font-display text-2xl font-bold">{money(offer.data?.amountMinor ?? 0)}<span className="ml-1 text-sm font-semibold text-muted-foreground">/ {offer.data?.interval}</span></p><p className="mt-3 text-xs text-muted-foreground">Offer is active on your public creator profile.</p></div>
          : offer.isLoading ? <p className="text-sm text-muted-foreground">Checking Stripe for your current offer…</p>
          : <OfferForm username={username} />}
      </div>
    </section>

    <section className="mt-6 rounded-[26px] border border-border bg-card p-5 sm:p-7">
      <h2 className="font-display text-xl font-bold">Your videos</h2>
      {studio.isLoading ? <p className="mt-4 text-sm text-muted-foreground">Loading…</p> : !studio.data?.topVideos.length ? <div className="mt-4 rounded-2xl border border-dashed border-border p-5 text-sm text-muted-foreground">No published videos yet. Video analytics will appear after you publish and signed-in viewers play your videos.</div> : <div className="mt-4 overflow-x-auto"><table className="w-full min-w-[520px] text-left text-sm"><thead><tr className="border-b border-border text-xs text-muted-foreground"><th className="pb-3">Video</th><th className="pb-3">Views</th><th className="pb-3">Playback</th><th className="pb-3">Audience</th></tr></thead><tbody>{studio.data.topVideos.map((video) => <tr key={video.id} className="border-b border-border last:border-0"><td className="max-w-[260px] truncate py-3 font-bold">{video.title}</td><td className="py-3">{video.views.toLocaleString()}</td><td className="py-3">{duration(video.watchTimeSeconds)}</td><td className="py-3">{video.audienceReach.toLocaleString()}</td></tr>)}</tbody></table></div>}
    </section>
    <p className="mt-6 text-xs leading-5 text-muted-foreground">Payouts are not enabled. Before any creator payout can go live, Stripe payout arrangements and applicable compliance requirements must be verified by the account owner.</p>
  </StudioShell>;
}
