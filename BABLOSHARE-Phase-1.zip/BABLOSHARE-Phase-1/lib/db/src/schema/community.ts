import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, pgEnum, pgTable, text, timestamp, uuid, varchar, primaryKey } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { profilesTable } from "./profiles";
import { usersTable } from "./users";
import { videosTable } from "./videos";
import { z } from "zod/v4";

export const groupTypeEnum = pgEnum("group_type", ["public", "private", "approval-required"]);
export const groupRoleEnum = pgEnum("group_role", ["admin", "moderator", "member"]);
export const groupMembershipStatusEnum = pgEnum("group_membership_status", ["active", "requested"]);
export const groupPostTypeEnum = pgEnum("group_post_type", ["update", "short", "long"]);
export const conversationReportStatusEnum = pgEnum("conversation_report_status", ["open", "resolved", "dismissed"]);

export const groupsTable = pgTable("groups", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  description: text("description").notNull().default(""),
  groupType: groupTypeEnum("group_type").notNull(),
  creatorId: uuid("creator_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const groupMembersTable = pgTable("group_members", {
  groupId: uuid("group_id").notNull().references(() => groupsTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  role: groupRoleEnum("role").notNull().default("member"),
  status: groupMembershipStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.groupId, table.userId] })]);

export const groupPostsTable = pgTable("group_posts", {
  id: uuid("id").defaultRandom().primaryKey(),
  groupId: uuid("group_id").notNull().references(() => groupsTable.id, { onDelete: "cascade" }),
  authorId: uuid("author_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  postType: groupPostTypeEnum("post_type").notNull().default("update"),
  content: text("content").notNull().default(""),
  videoId: uuid("video_id").references(() => videosTable.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertGroupSchema = createInsertSchema(groupsTable).omit({ id: true, creatorId: true, createdAt: true });
export const insertGroupPostSchema = createInsertSchema(groupPostsTable).omit({ id: true, authorId: true, createdAt: true });
export type InsertGroup = z.infer<typeof insertGroupSchema>;
export type InsertGroupPost = z.infer<typeof insertGroupPostSchema>;

export const pageTypeEnum = pgEnum("page_type", ["business", "creator", "brand"]);
export const pageAdminRoleEnum = pgEnum("page_admin_role", ["owner", "admin", "editor"]);

export const pagesTable = pgTable("pages", {
  id: uuid("id").defaultRandom().primaryKey(),
  ownerId: uuid("owner_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  username: varchar("username", { length: 32 }).notNull().unique(),
  pageType: pageTypeEnum("page_type").notNull(),
  bio: text("bio").notNull().default(""),
  avatarUrl: text("avatar_url"),
  coverUrl: text("cover_url"),
  isVerified: boolean("is_verified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const pageAdminsTable = pgTable("page_admins", {
  pageId: uuid("page_id").notNull().references(() => pagesTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  role: pageAdminRoleEnum("role").notNull().default("editor"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.pageId, table.userId] })]);

export const pageFollowersTable = pgTable("page_followers", {
  pageId: uuid("page_id").notNull().references(() => pagesTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.pageId, table.userId] })]);

export const insertPageSchema = createInsertSchema(pagesTable).omit({ id: true, ownerId: true, isVerified: true, createdAt: true });
export type InsertPage = z.infer<typeof insertPageSchema>;

export const storyMediaTypeEnum = pgEnum("story_media_type", ["photo", "short-video"]);
export const storyVisibilityEnum = pgEnum("story_visibility", ["public", "followers"]);

export const storiesTable = pgTable("stories", {
  id: uuid("id").defaultRandom().primaryKey(),
  authorId: uuid("author_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  mediaType: storyMediaTypeEnum("media_type").notNull(),
  mediaUrl: text("media_url").notNull(),
  visibility: storyVisibilityEnum("visibility").notNull().default("public"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull().default(sql`now() + interval '24 hours'`),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const storyViewsTable = pgTable("story_views", {
  storyId: uuid("story_id").notNull().references(() => storiesTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.storyId, table.userId] })]);

export const insertStorySchema = createInsertSchema(storiesTable).omit({ id: true, authorId: true, expiresAt: true, createdAt: true });
export type InsertStory = z.infer<typeof insertStorySchema>;

export const conversationsTable = pgTable("conversations", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 80 }).notNull().default("Conversation"),
  createdBy: uuid("created_by").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const conversationMembersTable = pgTable("conversation_members", {
  conversationId: uuid("conversation_id").notNull().references(() => conversationsTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  lastReadAt: timestamp("last_read_at", { withTimezone: true }),
  blockedAt: timestamp("blocked_at", { withTimezone: true }),
}, (table) => [primaryKey({ columns: [table.conversationId, table.userId] })]);

export const messagesTable = pgTable("messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id").notNull().references(() => conversationsTable.id, { onDelete: "cascade" }),
  senderId: uuid("sender_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  content: text("content").notNull().default(""),
  mediaUrl: text("media_url"),
  mediaType: varchar("media_type", { length: 16 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  readAt: timestamp("read_at", { withTimezone: true }),
});

export const messageReactionsTable = pgTable("message_reactions", {
  messageId: uuid("message_id").notNull().references(() => messagesTable.id, { onDelete: "cascade" }),
  userId: uuid("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  reaction: varchar("reaction", { length: 16 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [primaryKey({ columns: [table.messageId, table.userId, table.reaction] })]);

export const conversationReportsTable = pgTable("conversation_reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  conversationId: uuid("conversation_id").notNull().references(() => conversationsTable.id, { onDelete: "cascade" }),
  reporterId: uuid("reporter_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  reason: text("reason").notNull(),
  status: conversationReportStatusEnum("status").notNull().default("open"),
  reviewedBy: uuid("reviewed_by").references(() => usersTable.id, { onDelete: "set null" }),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertConversationSchema = createInsertSchema(conversationsTable).omit({ id: true, createdBy: true, createdAt: true, updatedAt: true });
export const insertMessageSchema = createInsertSchema(messagesTable).omit({ id: true, conversationId: true, senderId: true, createdAt: true, readAt: true });
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;