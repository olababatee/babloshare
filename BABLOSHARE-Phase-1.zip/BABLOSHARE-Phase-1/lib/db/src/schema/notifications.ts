import { index, pgEnum, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const notificationTypeEnum = pgEnum("notification_type", [
  "follow",
  "post_like",
  "post_comment",
  "video_like",
  "video_comment",
]);

export const notificationEntityTypeEnum = pgEnum("notification_entity_type", [
  "profile",
  "post",
  "video",
]);

export const notificationsTable = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  recipientId: uuid("recipient_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  actorId: uuid("actor_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  type: notificationTypeEnum("type").notNull(),
  entityType: notificationEntityTypeEnum("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("notifications_recipient_created_idx").on(table.recipientId, table.createdAt),
  index("notifications_recipient_read_idx").on(table.recipientId, table.readAt),
]);
