import { createInsertSchema } from "drizzle-zod";
import { integer, pgEnum, pgTable, text, timestamp, uuid, varchar } from "drizzle-orm/pg-core";
import { profilesTable } from "./profiles";
import { z } from "zod/v4";

export const videoTypeEnum = pgEnum("video_type", ["short", "long"]);

export const videosTable = pgTable("videos", {
  id: uuid("id").defaultRandom().primaryKey(),
  creatorId: uuid("creator_id").notNull().references(() => profilesTable.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 140 }).notNull(),
  description: text("description").notNull().default(""),
  videoType: videoTypeEnum("video_type").notNull(),
  playbackUrl: text("playback_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  viewsCount: integer("views_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertVideoSchema = createInsertSchema(videosTable).omit({ id: true, viewsCount: true, createdAt: true });
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Video = typeof videosTable.$inferSelect;