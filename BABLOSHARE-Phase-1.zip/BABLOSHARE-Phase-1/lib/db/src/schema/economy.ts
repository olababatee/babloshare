import { createInsertSchema } from "drizzle-zod";
import { integer, jsonb, pgEnum, pgTable, text, timestamp, uniqueIndex, uuid, varchar } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { videosTable } from "./videos";
import { z } from "zod/v4";

export const walletCurrencyEnum = pgEnum("wallet_currency", ["usd"]);
export const ledgerEntryTypeEnum = pgEnum("ledger_entry_type", ["tip", "subscription", "payout", "adjustment"]);
export const ledgerEntryStatusEnum = pgEnum("ledger_entry_status", ["pending", "available", "paid", "reversed"]);

export const walletsTable = pgTable("wallets", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().unique().references(() => usersTable.id, { onDelete: "cascade" }),
  currency: walletCurrencyEnum("currency").notNull().default("usd"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const ledgerEntriesTable = pgTable("ledger_entries", {
  id: uuid("id").defaultRandom().primaryKey(),
  walletId: uuid("wallet_id").notNull().references(() => walletsTable.id, { onDelete: "restrict" }),
  entryType: ledgerEntryTypeEnum("entry_type").notNull(),
  status: ledgerEntryStatusEnum("status").notNull().default("pending"),
  amount: integer("amount").notNull(),
  currency: walletCurrencyEnum("currency").notNull().default("usd"),
  stripePaymentIntentId: varchar("stripe_payment_intent_id", { length: 255 }),
  stripeCheckoutSessionId: varchar("stripe_checkout_session_id", { length: 255 }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }),
  idempotencyKey: varchar("idempotency_key", { length: 255 }).notNull().unique(),
  description: text("description").notNull().default(""),
  metadata: jsonb("metadata").$type<Record<string, string>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const creatorOffersTable = pgTable("creator_offers", {
  id: uuid("id").defaultRandom().primaryKey(),
  creatorId: uuid("creator_id").notNull().unique().references(() => usersTable.id, { onDelete: "cascade" }),
  stripeProductId: varchar("stripe_product_id", { length: 255 }).notNull(),
  stripePriceId: varchar("stripe_price_id", { length: 255 }).notNull(),
  active: integer("active").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [uniqueIndex("creator_offers_stripe_price_idx").on(table.stripePriceId)]);

export const videoViewEventsTable = pgTable("video_view_events", {
  id: uuid("id").defaultRandom().primaryKey(),
  videoId: uuid("video_id").notNull().references(() => videosTable.id, { onDelete: "cascade" }),
  viewerId: uuid("viewer_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  watchSeconds: integer("watch_seconds").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [uniqueIndex("video_view_events_viewer_video_idx").on(table.videoId, table.viewerId)]);

export const creatorSubscriptionsTable = pgTable("creator_subscriptions", {
  id: uuid("id").defaultRandom().primaryKey(),
  subscriberId: uuid("subscriber_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  creatorId: uuid("creator_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  stripeSubscriptionId: varchar("stripe_subscription_id", { length: 255 }).notNull().unique(),
  status: varchar("status", { length: 32 }).notNull(),
  currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertWalletSchema = createInsertSchema(walletsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertLedgerEntrySchema = createInsertSchema(ledgerEntriesTable).omit({ id: true, createdAt: true });
export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type InsertLedgerEntry = z.infer<typeof insertLedgerEntrySchema>;